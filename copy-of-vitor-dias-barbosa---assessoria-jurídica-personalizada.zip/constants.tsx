
import React from 'react';
import { PracticeArea, Lawyer, Article, Testimonial, OfficeStats, NavLinkItem } from './types';
import { UsersIcon, DocumentTextIcon, ScaleIcon, HomeModernIcon, BriefcaseIcon, BuildingStorefrontIcon, ShieldCheckIcon, ChatBubbleLeftRightIcon } from '@heroicons/react/24/outline';

export { BriefcaseIcon, UsersIcon, ScaleIcon, DocumentTextIcon, HomeModernIcon };

// URLs das Logos PNG
export const COMPANY_LOGO_URL_DARK_BG = "https://user-images.githubusercontent.com/171446593/291589395-9a1fd6e5-c0f6-4803-a409-6c10c29e41b0.png"; // Logo com texto claro para fundo escuro
export const COMPANY_LOGO_URL_LIGHT_BG = "https://user-images.githubusercontent.com/171446593/291589401-b233b67f-792a-4c9f-a712-3c073e43d03f.png"; // Logo com texto escuro para fundo claro


// Informações do Profissional/Escritório - ATUALIZADO
export const COMPANY_NAME = "Vitor Dias Barbosa";
export const COMPANY_SLOGAN = "Assessoria Jurídica Personalizada";
export const COMPANY_DESCRIPTION_INTERMEDIATOR = "Com uma sólida experiência em assessoria jurídica, Vitor Dias Barbosa se destaca por oferecer suporte especializado em diferentes áreas do direito. Como intermediador jurídico, ele atua conectando clientes aos serviços legais de que precisam, sempre com o compromisso de orientar sobre seus direitos e deveres. Sua missão é clara: garantir que cada cliente entenda e faça valer seus direitos, de maneira eficiente e estratégica, com uma abordagem personalizada e acessível. Vitor busca simplificar o caminho jurídico, trazendo soluções práticas e objetivas para quem precisa navegar no complexo sistema de leis.";
export const COMPANY_ADDRESS = "R. Álvares Penteado, 151 - Centro Histórico de São Paulo, São Paulo - SP, 01012-905";
export const COMPANY_PHONE = "(11) 91032-2670";
export const COMPANY_EMAIL = "contato@vitordiasbarbosa.adv.br"; // Placeholder, pode ser o mesmo do domínio anterior se preferir
export const WHATSAPP_NUMBER = "5511910322670";
export const COMPANY_WEBSITE_URL = "http://vitorbarbosaadv.com.br/"; // Manter o domínio fornecido anteriormente
export const COMPANY_INSTAGRAM_URL = "https://www.instagram.com/vitorbarbosa.adv";


// Áreas de Atuação - Descrições mais genéricas para um intermediador
export const PRACTICE_AREAS_DATA: PracticeArea[] = [
  {
    id: '1',
    slug: 'direito-de-familia-e-sucessoes',
    name: 'Direito de Família e Sucessões',
    icon: <UsersIcon />,
    descriptionShort: 'Orientação em divórcios, partilha, guarda, pensão, inventários e testamentos.',
    descriptionLong: 'Oferecemos suporte e direcionamento em questões sensíveis de Direito de Família, como divórcios, união estável, partilha de bens, guarda de filhos e pensão alimentícia. Em Sucessões, auxiliamos com inventários, testamentos e planejamento sucessório, conectando você aos especialistas adequados.',
    services: ['Orientação sobre Divórcio', 'Questões de União Estável', 'Diretrizes sobre Partilha de Bens', 'Informações sobre Guarda e Pensão', 'Assistência em Inventários', 'Planejamento Sucessório'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  {
    id: '2',
    slug: 'direito-civil-e-contratual',
    name: 'Direito Civil e Contratual',
    icon: <DocumentTextIcon />,
    descriptionShort: 'Suporte em contratos, responsabilidade civil, e questões possessórias.',
    descriptionLong: 'Fornecemos consultoria e direcionamento em Direito Civil, incluindo a análise de contratos, questões de responsabilidade civil (danos morais e materiais), e disputas possessórias. Conectamos você a profissionais para elaboração e revisão de contratos e demais necessidades.',
    services: ['Análise Contratual', 'Questões de Responsabilidade Civil', 'Direitos Possessórios', 'Consultoria em Contratos Diversos'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  {
    id: '3',
    slug: 'direito-do-consumidor',
    name: 'Direito do Consumidor',
    icon: <ShieldCheckIcon />,
    descriptionShort: 'Apoio em casos de produtos defeituosos, serviços inadequados e práticas abusivas.',
    descriptionLong: 'Atuamos como intermediador na defesa dos direitos dos consumidores, orientando em casos de produtos ou serviços defeituosos, publicidade enganosa, práticas abusivas e cobranças indevidas. Facilitamos o acesso a soluções e representação especializada.',
    services: ['Orientação sobre Vícios de Produtos/Serviços', 'Direitos em Publicidade Enganosa', 'Análise de Contratos de Adesão', 'Questões de Cobranças Indevidas'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  {
    id: '4',
    slug: 'direito-imobiliario',
    name: 'Direito Imobiliário',
    icon: <HomeModernIcon />,
    descriptionShort: 'Consultoria em transações imobiliárias, regularização, locações e condomínios.',
    descriptionLong: 'Prestamos suporte em Direito Imobiliário, abrangendo transações de compra e venda, locações, questões condominiais e regularização de imóveis. Conectamos você a especialistas para todas as etapas do processo imobiliário.',
    services: ['Consultoria em Compra e Venda', 'Questões de Locação', 'Direito Condominial', 'Regularização de Imóveis'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  // Expandido - Exemplos adicionais
  {
    id: '5',
    slug: 'direito-trabalhista',
    name: 'Direito Trabalhista',
    icon: <BriefcaseIcon />,
    descriptionShort: 'Orientação sobre direitos e deveres nas relações de trabalho.',
    descriptionLong: 'Fornecemos assessoria em questões de Direito Trabalhista, tanto para empregados quanto para empregadores, cobrindo temas como contratos de trabalho, rescisões, horas extras, e segurança no trabalho. Conectamos você a advogados especializados em litígios e consultoria trabalhista.',
    services: ['Consultoria em Contratos de Trabalho', 'Orientação sobre Rescisão Contratual', 'Direitos em Horas Extras e Adicionais', 'Questões de Assédio Moral e Sexual', 'Saúde e Segurança do Trabalho'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  {
    id: '6',
    slug: 'direito-empresarial',
    name: 'Direito Empresarial',
    icon: <BuildingStorefrontIcon />,
    descriptionShort: 'Suporte para constituição, gestão e resolução de conflitos empresariais.',
    descriptionLong: 'Assessoramos empresas em todas as fases, desde a constituição e elaboração de contratos sociais, até a gestão de conflitos societários e recuperação judicial. Conectamos a especialistas em M&A, propriedade intelectual e compliance.',
    services: ['Constituição de Empresas', 'Acordos de Sócios', 'Contratos Mercantis', 'Recuperação Judicial e Falência', 'Propriedade Intelectual e Marcas'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  {
    id: '7',
    slug: 'direito-tributario',
    name: 'Direito Tributário',
    icon: <ScaleIcon />, // Reutilizando para representar balança/justiça fiscal
    descriptionShort: 'Consultoria sobre impostos, planejamento tributário e contencioso fiscal.',
    descriptionLong: 'Oferecemos orientação em Direito Tributário, auxiliando na compreensão da complexa legislação fiscal brasileira, planejamento tributário estratégico e defesa em processos administrativos e judiciais fiscais. Conectamos a contadores e advogados tributaristas.',
    services: ['Planejamento Tributário', 'Consultoria sobre Impostos (ICMS, ISS, IRPJ, etc.)', 'Defesa em Execuções Fiscais', 'Recuperação de Créditos Tributários'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
  {
    id: '8',
    slug: 'direito-digital',
    name: 'Direito Digital',
    icon: <ChatBubbleLeftRightIcon />, // Reutilizando para representar comunicação/digital
    descriptionShort: 'Assessoria em questões de privacidade, crimes cibernéticos e contratos eletrônicos.',
    descriptionLong: 'No cenário digital, oferecemos suporte em questões de proteção de dados (LGPD), responsabilidade civil na internet, crimes cibernéticos, contratos eletrônicos e direito autoral online. Conectamos a peritos e especialistas em tecnologia.',
    services: ['Adequação à LGPD', 'Consultoria em Contratos Eletrônicos', 'Questões de Crimes Cibernéticos', 'Direito Autoral Online', 'Reputação Digital'],
    specialistLawyersIds: ['vitor-barbosa'],
  },
];

// Advogado Principal - ATUALIZADO
export const LAWYERS_DATA: Lawyer[] = [
  {
    id: 'vitor-barbosa',
    name: 'Vitor Dias Barbosa',
    photoUrl: 'https://user-images.githubusercontent.com/171446593/291587269-b807c9f8-3585-4a35-a75e-a58037d45147.jpeg', // Placeholder para a nova foto, substitua pela URL correta
    specialties: ['Intermediação Jurídica', 'Assessoria Personalizada'],
    bio: COMPANY_DESCRIPTION_INTERMEDIATOR, // Usar a descrição completa aqui
    education: [
      'Graduado em Direito',
      'Especializações em diversas áreas do Direito (detalhes sob consulta)'
    ],
    experience: [
      'Sólida experiência em assessoria e intermediação jurídica.',
      'Atuação em conectar clientes a soluções legais eficientes e personalizadas.'
    ],
    oab: 'OAB/SP 170.770', // Mantido número, alterado estado
    linkedin: 'https://www.linkedin.com/in/vitor-dias-barbosa-08506390/',
    email: COMPANY_EMAIL
  }
];

// Artigos do Blog - Mais artigos adicionados
export const ARTICLES_DATA: Article[] = [
  {
    id: '1',
    title: 'O Papel do Intermediador Jurídico na Resolução de Conflitos',
    slug: 'papel-intermediador-juridico',
    authorId: 'vitor-barbosa',
    date: '15 de Setembro, 2024',
    estimatedReadTime: '5 min',
    summary: 'Entenda como um intermediador jurídico como Vitor Dias Barbosa pode facilitar o acesso à justiça e a especialistas.',
    content: '<p>No complexo sistema legal, o intermediador jurídico surge como uma figura crucial para conectar pessoas e empresas aos serviços e profissionais adequados para suas necessidades. Vitor Dias Barbosa atua como essa ponte, garantindo que cada cliente receba um atendimento personalizado e direcionado. Este artigo explora a importância dessa função, os benefícios de contar com um intermediador e como esse profissional pode simplificar processos que, de outra forma, seriam áridos e desgastantes.</p><h3>Por que um Intermediador?</h3><p>Muitas vezes, o cidadão comum ou mesmo empresários se veem perdidos diante de uma questão legal. Não sabem a qual especialista recorrer, quais os primeiros passos a tomar ou mesmo quais são seus direitos. O intermediador jurídico qualificado, com sua rede de contatos e conhecimento multidisciplinar, avalia a situação e indica o caminho mais eficiente, seja para uma mediação, uma consultoria específica ou a representação em um litígio.</p>',
    tags: ['intermediação', 'acesso à justiça', 'assessoria'],
    category: 'Serviços Jurídicos',
    imageUrl: 'https://picsum.photos/seed/intermediadorVDB/800/400'
  },
  {
    id: '2',
    title: 'Navegando pelo Direito de Família: Como um Assessor Pode Ajudar',
    slug: 'navegando-direito-familia-assessor',
    authorId: 'vitor-barbosa',
    date: '22 de Setembro, 2024',
    estimatedReadTime: '7 min',
    summary: 'Questões de família exigem sensibilidade e conhecimento. Saiba como Vitor Dias Barbosa pode orientá-lo.',
    content: '<p>O Direito de Família abrange temas delicados como divórcio, guarda de filhos, pensão alimentícia e partilha de bens. São momentos que, além do desgaste emocional, envolvem complexidades legais. Contar com uma assessoria jurídica personalizada desde o início é fundamental para proteger seus direitos e buscar soluções justas e equilibradas. Vitor Dias Barbosa oferece o suporte necessário para entender cada etapa, conectando você a advogados especializados e experientes em mediação e litígio familiar, sempre com foco na preservação dos laços e no bem-estar dos envolvidos, especialmente crianças e adolescentes.</p>',
    tags: ['família', 'divórcio', 'assessoria', 'mediação'],
    category: 'Direito de Família e Sucessões',
    imageUrl: 'https://picsum.photos/seed/familiaVDB/800/400'
  },
  {
    id: '3',
    title: 'LGPD Comentada: O que sua Empresa Precisa Saber Urgente',
    slug: 'lgpd-comentada-empresa',
    authorId: 'vitor-barbosa',
    date: '01 de Outubro, 2024',
    estimatedReadTime: '8 min',
    summary: 'A Lei Geral de Proteção de Dados (LGPD) impacta todos os negócios. Entenda os pontos cruciais e como se adequar.',
    content: '<p>A Lei Geral de Proteção de Dados Pessoais (LGPD), Lei nº 13.709/2018, está em pleno vigor e sua empresa precisa estar atenta. Este artigo descomplica os principais aspectos da LGPD: o que são dados pessoais, quais os direitos dos titulares, as bases legais para tratamento de dados, e as responsabilidades dos agentes de tratamento (controlador e operador). Abordaremos também a importância do DPO (Data Protection Officer) e as sanções em caso de descumprimento. Vitor Dias Barbosa pode auxiliar sua empresa a entender o diagnóstico necessário e conectar com especialistas para a implementação de um programa de conformidade eficaz.</p>',
    tags: ['lgpd', 'proteção de dados', 'compliance', 'empresarial'],
    category: 'Direito Digital',
    imageUrl: 'https://picsum.photos/seed/lgpdVDB/800/400'
  },
  {
    id: '4',
    title: 'Contratos Empresariais: 5 Cláusulas Essenciais que Você Não Pode Ignorar',
    slug: 'contratos-empresariais-clausulas-essenciais',
    authorId: 'vitor-barbosa',
    date: '10 de Outubro, 2024',
    estimatedReadTime: '6 min',
    summary: 'Um contrato bem redigido é a base de qualquer negócio seguro. Conheça cláusulas vitais para seus acordos.',
    content: '<p>Contratos são a espinha dorsal das relações comerciais. Ignorar detalhes na sua elaboração pode levar a prejuízos significativos e longas disputas judiciais. Este artigo destaca cinco cláusulas que merecem atenção redobrada em qualquer contrato empresarial: objeto claro e preciso, condições de pagamento detalhadas, responsabilidades das partes, confidencialidade e a cláusula de resolução de disputas (arbitragem ou foro). Vitor Dias Barbosa oferece assessoria na análise e direcionamento para elaboração de contratos sólidos e seguros, conectando você a advogados contratualistas experientes.</p>',
    tags: ['contratos', 'empresarial', 'negócios', 'jurídico'],
    category: 'Direito Civil e Contratual',
    imageUrl: 'https://picsum.photos/seed/contratosVDB/800/400'
  },
  {
    id: '5',
    title: 'Direitos do Consumidor no E-commerce: Guia Completo',
    slug: 'direitos-consumidor-ecommerce',
    authorId: 'vitor-barbosa',
    date: '18 de Outubro, 2024',
    estimatedReadTime: '7 min',
    summary: 'Compras online são práticas, mas quais são seus direitos? Saiba como se proteger no comércio eletrônico.',
    content: '<p>O comércio eletrônico cresceu exponencialmente, e com ele, a necessidade de conhecer os direitos do consumidor nesse ambiente. Este guia aborda temas cruciais como o direito de arrependimento (7 dias para cancelar a compra), informações claras sobre o produto e o fornecedor, prazos de entrega, política de trocas e devoluções, e a segurança dos dados no pagamento. Vitor Dias Barbosa pode orientar sobre como proceder em caso de problemas e conectar você a especialistas em direito do consumidor digital.</p>',
    tags: ['consumidor', 'ecommerce', 'compras online', 'cdc'],
    category: 'Direito do Consumidor',
    imageUrl: 'https://picsum.photos/seed/ecommerceVDB/800/400'
  },
  {
    id: '6',
    title: 'Inventário Extrajudicial: Mais Rápido e Menos Burocrático?',
    slug: 'inventario-extrajudicial-vantagens',
    authorId: 'vitor-barbosa',
    date: '25 de Outubro, 2024',
    estimatedReadTime: '5 min',
    summary: 'Descubra se o inventário em cartório é uma opção para o seu caso e como ele pode agilizar a partilha de bens.',
    content: '<p>Quando um familiar falece, o inventário é o procedimento necessário para apurar os bens, direitos e dívidas do falecido, para então realizar a partilha entre os herdeiros. O inventário extrajudicial, feito diretamente em cartório, é uma alternativa mais célere e menos custosa que o judicial, mas exige o cumprimento de certos requisitos: todos os herdeiros devem ser maiores e capazes, deve haver consenso sobre a partilha, e o falecido não pode ter deixado testamento (salvo exceções). Vitor Dias Barbosa pode analisar seu caso e orientar sobre a viabilidade do inventário extrajudicial, conectando com os profissionais necessários.</p>',
    tags: ['inventário', 'sucessões', 'extrajudicial', 'partilha'],
    category: 'Direito de Família e Sucessões',
    imageUrl: 'https://picsum.photos/seed/inventarioVDB/800/400'
  },
  {
    id: '7',
    title: 'Reforma Trabalhista: Principais Mudanças que Afetam o Trabalhador',
    slug: 'reforma-trabalhista-impactos',
    authorId: 'vitor-barbosa',
    date: '05 de Novembro, 2024',
    estimatedReadTime: '9 min',
    summary: 'A reforma trabalhista trouxe alterações significativas. Entenda os pontos que mais impactam seus direitos e deveres.',
    content: '<p>A Lei nº 13.467/2017, conhecida como Reforma Trabalhista, alterou diversos pontos da Consolidação das Leis do Trabalho (CLT). Este artigo analisa algumas das principais mudanças, como a prevalência do negociado sobre o legislado, a regulamentação do teletrabalho (home office), as novas regras para férias, a contribuição sindical facultativa, e a criação do contrato de trabalho intermitente. Vitor Dias Barbosa oferece assessoria para que trabalhadores e empresas compreendam essas mudanças e seus reflexos nas relações de emprego, conectando a especialistas em direito e contencioso trabalhista.</p>',
    tags: ['reforma trabalhista', 'clt', 'direitos do trabalhador', 'emprego'],
    category: 'Direito Trabalhista',
    imageUrl: 'https://picsum.photos/seed/trabalhistaVDB/800/400'
  },
  {
    id: '8',
    title: 'Usucapião: Como Regularizar um Imóvel pela Posse',
    slug: 'usucapiao-regularizar-imovel',
    authorId: 'vitor-barbosa',
    date: '12 de Novembro, 2024',
    estimatedReadTime: '7 min',
    summary: 'A usucapião é uma forma de adquirir a propriedade de um imóvel pelo tempo de posse. Saiba como funciona.',
    content: '<p>Muitas pessoas possuem um imóvel há anos, cuidam dele como se fossem donas, mas não têm o registro formal em seu nome. A usucapião é o instrumento jurídico que permite regularizar essa situação, transformando a posse prolongada e qualificada em propriedade. Existem diferentes modalidades de usucapião (extraordinária, ordinária, especial urbana, especial rural), cada uma com seus requisitos específicos de tempo de posse e outras condições. Vitor Dias Barbosa pode analisar a sua situação e orientar sobre o processo de usucapião, conectando com advogados especialistas em direito imobiliário e regularização fundiária.</p>',
    tags: ['usucapião', 'imobiliário', 'posse', 'regularização'],
    category: 'Direito Imobiliário',
    imageUrl: 'https://picsum.photos/seed/usucapiaoVDB/800/400'
  },
  {
    id: '9',
    title: 'Planejamento Tributário para Pequenas Empresas: Como Pagar Menos Impostos Legalmente',
    slug: 'planejamento-tributario-pequenas-empresas',
    authorId: 'vitor-barbosa',
    date: '20 de Novembro, 2024',
    estimatedReadTime: '6 min',
    summary: 'Pequenas empresas também podem se beneficiar do planejamento tributário para otimizar sua carga fiscal.',
    content: '<p>A carga tributária no Brasil é um desafio para empresas de todos os portes. No entanto, através de um planejamento tributário eficiente e legal, é possível reduzir o montante de impostos pagos. Para pequenas empresas, a escolha do regime tributário adequado (Simples Nacional, Lucro Presumido ou Lucro Real) é um dos primeiros passos. Além disso, existem outras estratégias, como a correta classificação fiscal de produtos e serviços e o aproveitamento de incentivos fiscais. Vitor Dias Barbosa pode conectar sua empresa a contadores e advogados tributaristas para um planejamento eficaz.</p>',
    tags: ['tributário', 'impostos', 'pequenas empresas', 'planejamento'],
    category: 'Direito Tributário',
    imageUrl: 'https://picsum.photos/seed/tributarioVDB/800/400'
  },
  {
    id: '10',
    title: 'Mediação e Conciliação: Alternativas Eficazes à Justiça Comum',
    slug: 'mediacao-conciliacao-alternativas',
    authorId: 'vitor-barbosa',
    date: '28 de Novembro, 2024',
    estimatedReadTime: '5 min',
    summary: 'Nem todo conflito precisa ir ao tribunal. Conheça métodos alternativos de resolução de disputas.',
    content: '<p>A mediação e a conciliação são métodos alternativos de resolução de conflitos (MASCs) que buscam soluções consensuais entre as partes, com o auxílio de um terceiro imparcial (mediador ou conciliador). Esses métodos são geralmente mais rápidos, menos custosos e menos desgastantes emocionalmente do que um processo judicial. São aplicáveis a diversas áreas, como direito de família, questões cíveis e até mesmo empresariais. Vitor Dias Barbosa incentiva e orienta sobre o uso desses métodos, conectando as partes a mediadores e conciliadores qualificados.</p>',
    tags: ['mediação', 'conciliação', 'resolução de conflitos', 'justiça'],
    category: 'Serviços Jurídicos',
    imageUrl: 'https://picsum.photos/seed/mediacaoVDB/800/400'
  },
];

// Depoimentos - Ajustar para o novo contexto
export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: '1',
    clientName: 'Juliana M.',
    text: 'Vitor Dias Barbosa foi essencial para me conectar com o advogado certo para o meu caso. Muito grata pela orientação!',
    photoUrl: 'https://picsum.photos/seed/julianam/100/100',
    role: 'Cliente Orientada'
  },
  {
    id: '2',
    clientName: 'Roberto F.',
    text: 'A assessoria personalizada fez toda a diferença. Consegui entender meus direitos e os próximos passos.',
    photoUrl: 'https://picsum.photos/seed/robertof/100/100',
    role: 'Cliente Satisfeito'
  },
];

// Estatísticas - Manter genérico
export const OFFICE_STATS_DATA: OfficeStats = {
  casesWon: 150,      // Ajustar para números mais condizentes com "intermediador"
  clientsSatisfied: 300,
  yearsExperience: 8
};

// Links de Navegação
export const NAV_LINKS: NavLinkItem[] = [
  { label: 'Início', path: '/' },
  { label: 'Sobre Mim', path: '/sobre' }, // Alterado para "Sobre Mim"
  {
    label: 'Áreas de Suporte', // Alterado para "Áreas de Suporte"
    path: '/areas-atuacao',
    subItems: PRACTICE_AREAS_DATA.map(area => ({
      label: area.name,
      path: `/areas-atuacao/${area.slug}`
    }))
  },
  { label: 'Blog', path: '/blog' },
  { label: 'Contato', path: '/contato' },
];

// Logos para Certificações (Manter genérico ou buscar OAB SP)
export const OAB_LOGO_URL = "https://logodownload.org/wp-content/uploads/2017/05/oab-logo-2.png"; // Exemplo genérico OAB
