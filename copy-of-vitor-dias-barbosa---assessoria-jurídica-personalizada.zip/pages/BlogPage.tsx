import React, { useState } from 'react';
import PageHeader from '../components/PageHeader';
import ArticleCard from '../components/ArticleCard';
import { ARTICLES_DATA, COMPANY_NAME } from '../constants';
import { Article } from '../types';

const BlogPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');

  const categories = ['Todos', ...new Set(ARTICLES_DATA.map(article => article.category))];

  const filteredArticles = ARTICLES_DATA.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          article.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'Todos' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <PageHeader 
        title="Blog Jurídico"
        subtitle={`Artigos, notícias e análises sobre o universo jurídico. Mantenha-se informado com ${COMPANY_NAME}.`}
        imageUrl="https://picsum.photos/seed/blogvdb/1920/400"
      />

      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 font-sans">
          {/* Filters and Search */}
          <div className="mb-12 p-6 bg-light-gray rounded-lg shadow border border-gray-200">
            <div className="grid md:grid-cols-2 gap-6 items-end">
              <div>
                <label htmlFor="search" className="block text-sm font-medium text-brand-black mb-1">Buscar Artigos</label>
                <input
                  type="text"
                  id="search"
                  placeholder="Palavra-chave, título, tag..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-brand-black mb-1">Filtrar por Categoria</label>
                <select
                  id="category"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold bg-white"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  {categories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {filteredArticles.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.map(article => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-xl text-medium-gray">Nenhum artigo encontrado com os filtros atuais.</p>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default BlogPage;