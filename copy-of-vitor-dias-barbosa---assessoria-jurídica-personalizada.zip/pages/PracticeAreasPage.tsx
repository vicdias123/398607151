import React from 'react';
import PageHeader from '../components/PageHeader';
import PracticeAreaCard from '../components/PracticeAreaCard';
import { PRACTICE_AREAS_DATA } from '../constants';

const PracticeAreasPage: React.FC = () => {
  return (
    <>
      <PageHeader 
        title="Áreas de Suporte Jurídico"
        subtitle="Explore as áreas em que ofereço assessoria e intermediação, conectando você a soluções jurídicas eficazes."
        imageUrl="https://picsum.photos/seed/practiceareasvdb/1920/400"
      />

      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-lg text-medium-gray mb-12 text-center max-w-3xl mx-auto font-sans">
            Com uma abordagem personalizada, atuo como um facilitador no acesso a serviços jurídicos de qualidade. Minha assessoria abrange diversas áreas, sempre com o objetivo de direcionar você para o melhor caminho e, se necessário, para os especialistas mais qualificados.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {PRACTICE_AREAS_DATA.map(area => (
              <PracticeAreaCard key={area.id} area={area} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default PracticeAreasPage;