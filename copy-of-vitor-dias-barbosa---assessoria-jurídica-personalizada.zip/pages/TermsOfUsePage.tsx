import React from 'react';
import PageHeader from '../components/PageHeader';
import { COMPANY_NAME, COMPANY_EMAIL } from '../constants';

const TermsOfUsePage: React.FC = () => {
  return (
    <>
      <PageHeader 
        title="Termos de Uso"
        subtitle={`Regras para a utilização do site e serviços de ${COMPANY_NAME}.`}
        imageUrl="https://picsum.photos/seed/termsofusevdb/1920/400"
      />
      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-3xl mx-auto text-medium-gray leading-relaxed font-sans">
            <p className="text-sm text-medium-gray mb-6">Última atualização: {new Date().toLocaleDateString('pt-BR')}</p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">1. Aceitação dos Termos</h2>
            <p>
              Ao acessar e utilizar o site de ${COMPANY_NAME} ("Site"), você concorda em cumprir e estar vinculado a estes Termos de Uso ("Termos"). Se você não concordar com qualquer parte dos Termos, não deverá utilizar o Site.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">2. Uso do Site</h2>
            <p>
              O Site e seu conteúdo são fornecidos apenas para fins informativos gerais sobre meus serviços de assessoria e intermediação jurídica. As informações aqui contidas não constituem aconselhamento jurídico e não devem ser consideradas como tal. A utilização do Site não estabelece uma relação advogado-cliente, a menos que formalizada por contrato específico.
            </p>
            <p>Você concorda em não utilizar o Site para:</p>
            <ul>
              <li>Qualquer finalidade ilegal ou não autorizada.</li>
              <li>Transmitir vírus, worms ou qualquer código de natureza destrutiva.</li>
              <li>Coletar ou rastrear informações pessoais de outros sem consentimento.</li>
              <li>Interferir ou contornar os recursos de segurança do Site.</li>
            </ul>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">3. Propriedade Intelectual</h2>
            <p>
              Todo o conteúdo presente no Site, incluindo, mas não se limitando a, textos, gráficos, logotipos, ícones, imagens, é propriedade de ${COMPANY_NAME} ou de seus licenciadores e é protegido pelas leis de direitos autorais e outras leis de propriedade intelectual do Brasil.
            </p>
            <p>
              Nenhuma parte do Site pode ser copiada, reproduzida, republicada, carregada, postada, transmitida ou distribuída de qualquer forma sem meu consentimento prévio por escrito, exceto para visualização pessoal e não comercial.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">4. Limitação de Responsabilidade</h2>
            <p>
              O Site é fornecido "como está" e "conforme disponível". Não ofereço garantias, expressas ou implícitas, sobre a operação do Site ou as informações e conteúdos incluídos. Esforço-me para manter as informações atualizadas e precisas, mas não garanto sua completude ou exatidão.
            </p>
            <p>
              Em nenhuma circunstância ${COMPANY_NAME} será responsável por quaisquer danos diretos, indiretos, incidentais, especiais, consequenciais ou punitivos decorrentes do uso ou da incapacidade de usar o Site.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">5. Links para Sites de Terceiros</h2>
            <p>
              O Site pode conter links para sites de terceiros que não são de minha propriedade ou controlados por mim. Não tenho controle e não assumo responsabilidade pelo conteúdo, políticas de privacidade ou práticas de quaisquer sites de terceiros.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">6. Modificações dos Termos</h2>
            <p>
              Reservo-me o direito de modificar estes Termos a qualquer momento. Quaisquer alterações entrarão em vigor imediatamente após a publicação no Site. Seu uso continuado do Site após tais alterações constitui sua aceitação dos novos Termos.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">7. Lei Aplicável e Foro</h2>
            <p>
              Estes Termos serão regidos e interpretados de acordo com as leis da República Federativa do Brasil. Fica eleito o foro da comarca de São Paulo, Estado de São Paulo, para dirimir quaisquer controvérsias oriundas destes Termos.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">8. Contato</h2>
            <p>
              Se você tiver alguma dúvida sobre estes Termos de Uso, entre em contato:
            </p>
            <p>
              {COMPANY_NAME}<br />
              Email: <a href={`mailto:${COMPANY_EMAIL}`} className="text-brand-gold hover:underline">{COMPANY_EMAIL}</a>
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default TermsOfUsePage;