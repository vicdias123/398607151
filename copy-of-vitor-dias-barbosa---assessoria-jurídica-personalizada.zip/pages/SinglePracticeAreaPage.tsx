import React from 'react';
import { useParams, Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import { PRACTICE_AREAS_DATA, LAWYERS_DATA, ARTICLES_DATA } from '../constants';
import { Lawyer, Article } from '../types';
import ArticleCard from '../components/ArticleCard';
import ContactForm from '../components/ContactForm';
import { ChevronRightIcon } from '@heroicons/react/24/solid';

const SinglePracticeAreaPage: React.FC = () => {
  const { areaId } = useParams<{ areaId: string }>();
  const area = PRACTICE_AREAS_DATA.find(a => a.slug === areaId);

  if (!area) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="font-display text-3xl font-bold text-brand-black mb-4">Área de Suporte não encontrada.</h1>
        <Link to="/areas-atuacao" className="text-brand-gold hover:underline">
          Voltar para todas as áreas
        </Link>
      </div>
    );
  }
  
  // Como o foco é no Vitor Dias Barbosa, ele é o especialista.
  const specialistLawyer: Lawyer | undefined = LAWYERS_DATA.find(lawyer => lawyer.id === 'vitor-barbosa');

  const relatedArticles: Article[] = ARTICLES_DATA.filter(article => article.category === area.name).slice(0,2);

  return (
    <>
      <PageHeader 
        title={area.name}
        subtitle={area.descriptionShort}
        imageUrl={`https://picsum.photos/seed/singlearea-${area.slug}/1920/400`}
      />
      <div className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <div className="prose prose-lg max-w-none text-medium-gray leading-relaxed font-sans">
                <p className="text-lg mb-6">{area.descriptionLong}</p>

                <h2 className="font-display text-2xl font-semibold text-brand-black mt-10 mb-4">Serviços e Orientações</h2>
                <ul className="list-none space-y-2 mb-8 pl-0">
                  {area.services.map((service, index) => (
                    <li key={index} className="flex items-start">
                        <ChevronRightIcon className="w-5 h-5 text-brand-gold mr-2 mt-1 flex-shrink-0" />
                        <span>{service}</span>
                    </li>
                  ))}
                </ul>

                {area.faq && area.faq.length > 0 && (
                  <>
                    <h2 className="font-display text-2xl font-semibold text-brand-black mt-10 mb-4">Perguntas Frequentes (FAQ)</h2>
                    <div className="space-y-6">
                      {area.faq.map((item, index) => (
                        <div key={index} className="bg-light-gray p-4 rounded-md border border-gray-200">
                          <h4 className="font-semibold text-brand-gold">{item.question}</h4>
                          <p className="text-sm mt-1">{item.answer}</p>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <aside className="lg:col-span-1 space-y-10">
              {specialistLawyer && (
                <div className="bg-light-gray p-6 rounded-lg shadow-md border border-gray-200">
                  <h3 className="font-display text-xl font-semibold text-brand-black mb-4">Assessoria por</h3>
                  <div className="flex items-center">
                    <img src={specialistLawyer.photoUrl} alt={specialistLawyer.name} className="w-16 h-16 rounded-full mr-4 object-cover border-2 border-brand-gold"/>
                    <div>
                      <Link to={`/equipe/${specialistLawyer.id}`} className="font-medium text-brand-gold hover:underline font-display">{specialistLawyer.name}</Link>
                      <p className="text-xs text-medium-gray font-sans">{specialistLawyer.specialties.join(', ')}</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="bg-light-gray p-6 rounded-lg shadow-md border border-gray-200">
                <h3 className="font-display text-xl font-semibold text-brand-black mb-4">Fale Comigo sobre {area.name}</h3>
                <ContactForm />
              </div>

              {relatedArticles.length > 0 && (
                <div className="bg-light-gray p-6 rounded-lg shadow-md border border-gray-200">
                  <h3 className="font-display text-xl font-semibold text-brand-black mb-4">Artigos Relacionados</h3>
                  <div className="space-y-6">
                    {relatedArticles.map(article => (
                        <ArticleCard key={article.id} article={article} />
                    ))}
                  </div>
                </div>
              )}
            </aside>
          </div>
        </div>
      </div>
    </>
  );
};

export default SinglePracticeAreaPage;