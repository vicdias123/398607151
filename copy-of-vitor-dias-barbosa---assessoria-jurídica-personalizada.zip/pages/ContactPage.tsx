import React from 'react';
import PageHeader from '../components/PageHeader';
import ContactForm from '../components/ContactForm';
import { COMPANY_ADDRESS, COMPANY_PHONE, COMPANY_EMAIL, COMPANY_NAME, COMPANY_INSTAGRAM_URL, LAWYERS_DATA } from '../constants';
import { MapPinIcon, PhoneIcon, EnvelopeIcon, ClockIcon } from '@heroicons/react/24/solid';

const ContactPage: React.FC = () => {
  const mapQuery = encodeURIComponent(COMPANY_ADDRESS);
  const mapUrl = `https://maps.google.com/maps?q=${mapQuery}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

  return (
    <>
      <PageHeader 
        title="Entre em Contato"
        subtitle={`Estou à disposição para ouvir você. Utilize o formulário abaixo ou meus canais de contato para falar sobre suas necessidades jurídicas.`}
        imageUrl="https://picsum.photos/seed/contactvdb/1920/400"
      />

      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="font-display text-2xl md:text-3xl font-semibold text-brand-black mb-6">Envie sua Mensagem</h2>
              <ContactForm isDetailed={true} />
            </div>

            {/* Contact Information */}
            <div className="bg-light-gray p-8 rounded-lg shadow-lg border border-gray-200 font-sans">
              <h2 className="font-display text-2xl md:text-3xl font-semibold text-brand-black mb-8">Minhas Informações</h2>
              
              <div className="space-y-6 text-medium-gray">
                <div className="flex items-start">
                  <MapPinIcon className="w-8 h-8 text-brand-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-brand-black text-lg">Endereço</h4>
                    <p>{COMPANY_ADDRESS}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <PhoneIcon className="w-7 h-7 text-brand-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-brand-black text-lg">Telefone</h4>
                    <p><a href={`tel:${COMPANY_PHONE.replace(/\D/g,'')}`} className="hover:text-brand-gold">{COMPANY_PHONE}</a></p>
                  </div>
                </div>
                <div className="flex items-start">
                  <EnvelopeIcon className="w-7 h-7 text-brand-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-brand-black text-lg">Email</h4>
                    <p><a href={`mailto:${COMPANY_EMAIL}`} className="hover:text-brand-gold">{COMPANY_EMAIL}</a></p>
                  </div>
                </div>
                <div className="flex items-start">
                  <ClockIcon className="w-7 h-7 text-brand-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-brand-black text-lg">Horário de Atendimento</h4>
                    <p>Segunda a Sexta: 9:00 - 18:00</p>
                  </div>
                </div>
              </div>

              <div className="mt-10">
                <h4 className="font-display font-semibold text-brand-black text-lg mb-3">Siga-me</h4>
                <div className="flex space-x-4">
                   <a href={COMPANY_INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="text-brand-gold hover:opacity-80 transition-opacity duration-300">
                    <i className="fab fa-instagram fa-2x"></i>
                  </a>
                  <a href={LAWYERS_DATA[0].linkedin || "#"} target="_blank" rel="noopener noreferrer" className="text-brand-gold hover:opacity-80 transition-opacity duration-300">
                    <i className="fab fa-linkedin fa-2x"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="pb-16 bg-light-gray pt-10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
             <h2 className="font-display text-2xl md:text-3xl font-semibold text-brand-black mb-6 text-center">Como Chegar</h2>
            <div className="aspect-w-16 aspect-h-9 rounded-lg shadow-xl overflow-hidden border-2 border-brand-gold">
              <iframe
                src={mapUrl}
                width="100%"
                height="450"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title={`Localização de ${COMPANY_NAME}`}
              ></iframe>
            </div>
          </div>
      </section>
    </>
  );
};

export default ContactPage;