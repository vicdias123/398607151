import React, { useState } from 'react';
import PageHeader from '../components/PageHeader';
import { ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/solid';
import { COMPANY_NAME, PRACTICE_AREAS_DATA } from '../constants';

interface FAQItemData {
  question: string;
  answer: string;
  category: string;
}

const faqData: FAQItemData[] = [
  {
    category: 'Sobre a Assessoria',
    question: `Como ${COMPANY_NAME} pode me ajudar?`,
    answer: `${COMPANY_NAME} atua como um assessor e intermediador jurídico. Minha função é entender sua necessidade, oferecer orientação inicial e, quando necessário, conectar você aos profissionais e serviços jurídicos mais adequados para o seu caso específico.`
  },
  {
    category: 'Sobre a Assessoria',
    question: 'Em quais áreas do direito você oferece suporte?',
    answer: `Ofereço suporte e direcionamento em diversas áreas, incluindo ${PRACTICE_AREAS_DATA.map(area => area.name).slice(0, -1).join(', ')} e ${PRACTICE_AREAS_DATA.slice(-1)[0].name}. Meu objetivo é garantir que você receba a melhor orientação possível.`
  },
  {
    category: 'Sobre a Assessoria',
    question: 'Como posso marcar uma consulta ou solicitar assessoria?',
    answer: 'Você pode entrar em contato através do formulário em nosso site, por telefone ou e-mail. Vamos conversar sobre sua situação para que eu possa oferecer o melhor direcionamento.'
  },
  {
    category: 'Serviços',
    question: 'Você atua diretamente nos processos judiciais?',
    answer: 'Minha principal atuação é como assessor e intermediador, o que significa que eu oriento e conecto você a advogados especialistas que podem representá-lo em processos judiciais, se necessário. Garanto o acompanhamento e a qualidade do serviço.'
  },
  {
    category: 'Honorários',
    question: 'Como funcionam os custos da assessoria?',
    answer: 'Os custos da assessoria inicial e da intermediação são discutidos de forma transparente e dependem da complexidade da sua necessidade. Caso haja necessidade de contratação de advogados parceiros, os honorários destes serão apresentados e acordados diretamente com eles, sempre com meu acompanhamento para garantir clareza.'
  },
];

const FAQPage: React.FC = () => {
  const [openAccordion, setOpenAccordion] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setOpenAccordion(openAccordion === index ? null : index);
  };
  
  const categories = [...new Set(faqData.map(item => item.category))];

  return (
    <>
      <PageHeader 
        title="Perguntas Frequentes (FAQ)"
        subtitle="Encontre respostas rápidas para as dúvidas mais comuns sobre meus serviços de assessoria e intermediação jurídica."
        imageUrl="https://picsum.photos/seed/faqvdb/1920/400"
      />
      <section className="py-16 bg-brand-white font-sans">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            {categories.map(category => (
              <div key={category} className="mb-10">
                <h2 className="font-display text-2xl font-semibold text-brand-black mb-6 border-b-2 border-brand-light-gold pb-2">{category}</h2>
                <div className="space-y-4">
                  {faqData.filter(item => item.category === category).map((item, index) => {
                    const globalIndex = faqData.findIndex(fi => fi.question === item.question && fi.answer === item.answer); // Recalcula o índice global
                    return (
                    <div key={globalIndex} className="border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                      <button
                        onClick={() => toggleAccordion(globalIndex)}
                        className="w-full flex justify-between items-center p-4 text-left text-dark-gray hover:bg-light-gray focus:outline-none"
                        aria-expanded={openAccordion === globalIndex}
                        aria-controls={`faq-content-${globalIndex}`}
                      >
                        <span className="font-medium">{item.question}</span>
                        {openAccordion === globalIndex ? (
                          <ChevronUpIcon className="w-6 h-6 text-brand-gold" />
                        ) : (
                          <ChevronDownIcon className="w-6 h-6 text-medium-gray" />
                        )}
                      </button>
                      {openAccordion === globalIndex && (
                        <div id={`faq-content-${globalIndex}`} className="p-4 bg-gray-50 border-t border-gray-200">
                          <p className="text-medium-gray leading-relaxed">{item.answer}</p>
                        </div>
                      )}
                    </div>
                  )})}
                </div>
              </div>
            ))}
             <div className="mt-12 text-center p-8 bg-brand-black text-brand-white rounded-lg shadow-xl">
                <h3 className="font-display text-2xl font-semibold text-brand-gold mb-3">Não encontrou sua resposta?</h3>
                <p className="mb-6 text-brand-light-gold">Entre em contato. Estou aqui para ajudar!</p>
                <a 
                    href="#/contato"
                    className="inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-8 rounded-lg shadow-md transition-colors"
                >
                    Fale Comigo
                </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default FAQPage;