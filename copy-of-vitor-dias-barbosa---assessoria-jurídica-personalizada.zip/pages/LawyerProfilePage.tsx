
import React from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
// Fix: Import COMPANY_PHONE from constants
import { LAWYERS_DATA, COMPANY_NAME, COMPANY_PHONE } from '../constants';
import { EnvelopeIcon, LinkIcon, BuildingLibraryIcon, PhoneIcon } from '@heroicons/react/24/outline';

const LawyerProfilePage: React.FC = () => {
  const { lawyerId } = useParams<{ lawyerId: string }>();
  const lawyer = LAWYERS_DATA.find(l => l.id === lawyerId);
  const location = useLocation();
  const contactReason = location.state?.contactReason;


  if (!lawyer) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="font-display text-3xl font-bold text-brand-black mb-4">Profissional não encontrado.</h1>
        <Link to="/equipe" className="text-brand-gold hover:underline">
          Voltar
        </Link>
      </div>
    );
  }

  return (
    <>
      <PageHeader 
        title={lawyer.name}
        subtitle={lawyer.specialties.join(' | ')}
        imageUrl={`https://picsum.photos/seed/profilebg-${lawyer.id}/1920/400`}
      />
      <div className="py-16 bg-light-gray">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-brand-white p-8 md:p-12 rounded-xl shadow-2xl border border-gray-200">
            <div className="grid md:grid-cols-3 gap-8 md:gap-12 items-start">
              {/* Left Column: Photo and Contact */}
              <div className="md:col-span-1 text-center">
                <img 
                  src={lawyer.photoUrl} 
                  alt={lawyer.name} 
                  className="w-48 h-48 md:w-64 md:h-64 rounded-full mx-auto mb-6 object-cover shadow-lg border-4 border-brand-gold"
                />
                <h2 className="font-display text-2xl font-bold text-brand-black mb-1">{lawyer.name}</h2>
                <p className="text-brand-gold font-medium mb-4 font-sans">{lawyer.specialties.join(', ')}</p>
                <div className="space-y-2 text-sm text-medium-gray font-sans">
                  <p className="flex items-center justify-center">
                    <BuildingLibraryIcon className="w-5 h-5 mr-2 text-brand-gold" />
                    OAB: {lawyer.oab}
                  </p>
                   <p className="flex items-center justify-center">
                    <PhoneIcon className="w-5 h-5 mr-2 text-brand-gold" />
                    <a href={`tel:${COMPANY_PHONE.replace(/\D/g,'')}`} className="hover:text-brand-gold">{COMPANY_PHONE}</a> {/* Usando o telefone principal */}
                  </p>
                  <p className="flex items-center justify-center">
                    <EnvelopeIcon className="w-5 h-5 mr-2 text-brand-gold" />
                    <a href={`mailto:${lawyer.email}`} className="hover:text-brand-gold">{lawyer.email}</a>
                  </p>
                  {lawyer.linkedin && (
                    <p className="flex items-center justify-center">
                      <LinkIcon className="w-5 h-5 mr-2 text-brand-gold" />
                      <a href={lawyer.linkedin} target="_blank" rel="noopener noreferrer" className="hover:text-brand-gold">LinkedIn</a>
                    </p>
                  )}
                </div>
                <Link 
                  to="/contato" 
                  state={{ lawyerName: lawyer.name, contactReason: contactReason || `Consulta com ${lawyer.name}` }}
                  className="mt-6 inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-6 rounded-lg shadow-md transition-colors"
                >
                  Contatar {lawyer.name.split(' ')[0]}
                </Link>
              </div>

              {/* Right Column: Bio, Education, Experience */}
              <div className="md:col-span-2 font-sans">
                <section className="mb-8">
                  <h3 className="font-display text-xl font-semibold text-brand-black border-b-2 border-brand-light-gold pb-2 mb-4">Sobre Mim</h3>
                  <p className="text-medium-gray leading-relaxed whitespace-pre-line">{lawyer.bio}</p>
                </section>

                <section className="mb-8">
                  <h3 className="font-display text-xl font-semibold text-brand-black border-b-2 border-brand-light-gold pb-2 mb-4">Formação Acadêmica</h3>
                  <ul className="list-disc list-inside text-medium-gray space-y-1">
                    {lawyer.education.map((edu, index) => <li key={index}>{edu}</li>)}
                  </ul>
                </section>

                <section>
                  <h3 className="font-display text-xl font-semibold text-brand-black border-b-2 border-brand-light-gold pb-2 mb-4">Experiência Profissional</h3>
                  <ul className="list-disc list-inside text-medium-gray space-y-1">
                    {lawyer.experience.map((exp, index) => <li key={index}>{exp}</li>)}
                  </ul>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LawyerProfilePage;