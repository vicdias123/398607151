import React from 'react';
import PageHeader from '../components/PageHeader';
import { COMPANY_NAME, COMPANY_EMAIL, COMPANY_ADDRESS } from '../constants';

const PrivacyPolicyPage: React.FC = () => {
  return (
    <>
      <PageHeader 
        title="Política de Privacidade"
        subtitle={`Saiba como ${COMPANY_NAME} coleta, usa e protege suas informações.`}
        imageUrl="https://picsum.photos/seed/privacypolicyvdb/1920/400"
      />
      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-3xl mx-auto text-medium-gray leading-relaxed font-sans">
            <p className="text-sm text-medium-gray mb-6">Última atualização: {new Date().toLocaleDateString('pt-BR')}</p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">1. Introdução</h2>
            <p>
              Bem-vindo à Política de Privacidade de ${COMPANY_NAME}. Valorizo sua privacidade e estou comprometido em proteger suas informações pessoais. Esta política descreve como coleto, uso, armazeno, compartilho e protejo suas informações quando você utiliza meu site e meus serviços de assessoria e intermediação jurídica.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">2. Informações que Coletamos</h2>
            <p>Posso coletar os seguintes tipos de informações:</p>
            <ul>
              <li><strong>Informações Pessoais Fornecidas por Você:</strong> Nome, endereço de e-mail, número de telefone, informações sobre seu caso ou consulta, e quaisquer outros dados que você me forneça voluntariamente através de formulários de contato, e-mails ou outras comunicações.</li>
              <li><strong>Informações de Uso do Site:</strong> Endereço IP, tipo de navegador, sistema operacional, páginas visitadas, tempo gasto no site, links clicados e outras informações de tráfego e uso coletadas através de cookies e tecnologias similares.</li>
            </ul>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">3. Como Usamos Suas Informações</h2>
            <p>Utilizo suas informações para os seguintes propósitos:</p>
            <ul>
              <li>Fornecer, operar e manter meus serviços de assessoria e intermediação jurídica.</li>
              <li>Responder às suas consultas, solicitações e fornecer suporte.</li>
              <li>Melhorar meu site, serviços e a experiência do usuário.</li>
              <li>Comunicarmo-nos com você sobre meus serviços, atualizações e notícias relevantes (com seu consentimento, quando aplicável).</li>
              <li>Cumprir obrigações legais e regulatórias.</li>
              <li>Analisar o uso do site para fins estatísticos e de aprimoramento.</li>
            </ul>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">4. Compartilhamento de Informações</h2>
            <p>
              Não vendo, alugo ou troco suas informações pessoais com terceiros para fins de marketing. Posso compartilhar suas informações nas seguintes circunstâncias:
            </p>
            <ul>
              <li>Com prestadores de serviços terceirizados que me auxiliam na operação do site e na prestação de serviços (ex: hospedagem, análise de dados), desde que eles concordem em manter suas informações confidenciais.</li>
              <li>Quando exigido por lei, processo legal ou solicitação governamental.</li>
              <li>Para proteger meus direitos, propriedade ou segurança, ou os direitos, propriedade ou segurança de meus usuários ou do público.</li>
              <li>Com seu consentimento explícito.</li>
            </ul>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">5. Segurança de Dados</h2>
            <p>
              Implemento medidas de segurança técnicas e organizacionais apropriadas para proteger suas informações pessoais contra acesso não autorizado, alteração, divulgação ou destruição. No entanto, nenhum método de transmissão pela Internet ou armazenamento eletrônico é 100% seguro.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">6. Seus Direitos</h2>
            <p>
              De acordo com a Lei Geral de Proteção de Dados (LGPD), você tem o direito de acessar, corrigir, atualizar ou solicitar a exclusão de suas informações pessoais. Você também pode ter o direito de restringir ou se opor ao processamento de seus dados, solicitar a portabilidade dos dados e revogar o consentimento. Para exercer esses direitos, entre em contato comigo através do e-mail {COMPANY_EMAIL}.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">7. Cookies</h2>
            <p>
              Meu site pode usar cookies para melhorar a experiência do usuário. Cookies são pequenos arquivos de texto armazenados em seu dispositivo. Você pode configurar seu navegador para recusar todos os cookies ou para indicar quando um cookie está sendo enviado. No entanto, algumas funcionalidades do site podem não funcionar corretamente sem cookies. Utilizo cookies para análise de tráfego e personalização de conteúdo.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">8. Alterações nesta Política de Privacidade</h2>
            <p>
              Posso atualizar esta Política de Privacidade periodicamente. Notificarei sobre quaisquer alterações publicando a nova política em meu site e atualizando a data da "Última atualização". Recomendo que você revise esta política regularmente para se manter informado sobre como protejo suas informações.
            </p>

            <h2 className="font-display text-2xl font-semibold text-brand-black mt-8 mb-4">9. Contato</h2>
            <p>
              Se você tiver alguma dúvida ou preocupação sobre esta Política de Privacidade ou minhas práticas de dados, entre em contato:
            </p>
            <p>
              {COMPANY_NAME}<br />
              Email: <a href={`mailto:${COMPANY_EMAIL}`} className="text-brand-gold hover:underline">{COMPANY_EMAIL}</a><br />
              Endereço: {COMPANY_ADDRESS}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default PrivacyPolicyPage;