import React from 'react';
import HeroSection from '../components/HeroSection';
import AboutMeSummary from '../components/AboutUsSummary'; // Renomeado
import PracticeAreasHighlight from '../components/PracticeAreasHighlight';
// import TeamPreview from '../components/TeamPreview'; // Removido pois o foco é individual
import BlogPreview from '../components/BlogPreview';
import StatsSection from '../components/StatsSection';
import ContactForm from '../components/ContactForm';
import MapSection from '../components/MapSection';
import CertificationsSection from '../components/CertificationsSection';
import TestimonialCard from '../components/TestimonialCard';
import { TESTIMONIALS_DATA } from '../constants';

const HomePage: React.FC = () => {
  return (
    <>
      <HeroSection />
      <AboutMeSummary />
      <PracticeAreasHighlight />
      
      <section className="py-16 bg-light-gray">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-black mb-4">O Que Dizem Sobre Meu Trabalho</h2>
            <p className="text-lg text-medium-gray max-w-2xl mx-auto font-sans">
              A satisfação de quem confia em minha assessoria é minha maior recompensa.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {TESTIMONIALS_DATA.slice(0,2).map(testimonial => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* <TeamPreview />  Removido */}
      <StatsSection />
      <BlogPreview />

      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-black mb-4">Entre em Contato</h2>
            <p className="text-lg text-medium-gray max-w-xl mx-auto font-sans">
              Tem alguma dúvida ou precisa de assessoria jurídica? Fale comigo.
            </p>
          </div>
          <div className="max-w-2xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
      
      <MapSection />
      <CertificationsSection />
    </>
  );
};

export default HomePage;