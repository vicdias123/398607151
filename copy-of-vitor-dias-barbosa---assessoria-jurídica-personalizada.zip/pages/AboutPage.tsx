import React from 'react';
import PageHeader from '../components/PageHeader';
import { COMPANY_NAME, COMPANY_DESCRIPTION_INTERMEDIATOR, LAWYERS_DATA } from '../constants';
import { AcademicCapIcon, BuildingOffice2Icon, ShieldCheckIcon, UsersIcon, SparklesIcon, HandRaisedIcon } from '@heroicons/react/24/outline';

const AboutPage: React.FC = () => {
  const lawyer = LAWYERS_DATA[0]; // Assuming Vitor is the first/only one

  return (
    <>
      <PageHeader 
        title={`Sobre Mim - ${COMPANY_NAME}`}
        subtitle="Conheça minha trajetória, filosofia de trabalho e como posso auxiliar você a encontrar as melhores soluções jurídicas."
        imageUrl="https://picsum.photos/seed/aboutbgvdb/1920/400"
      />

      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div className="prose prose-lg max-w-none text-medium-gray">
              <h2 className="font-display text-3xl font-semibold text-brand-black mb-6">Minha Abordagem</h2>
              <p className="leading-relaxed mb-4">
                {COMPANY_DESCRIPTION_INTERMEDIATOR}
              </p>
              <p className="leading-relaxed">
                Minha experiência permite uma análise apurada de cada situação, identificando as melhores estratégias e os profissionais mais qualificados para cada tipo de demanda. Acredito que o acesso à justiça deve ser simplificado e humanizado.
              </p>
            </div>
            <div>
              <img 
                src={lawyer.photoUrl} 
                alt={`Vitor Dias Barbosa`}
                className="rounded-lg shadow-xl w-full max-w-md mx-auto h-auto object-cover border-4 border-brand-gold"
              />
            </div>
          </div>

          <div className="mb-16">
            <h2 className="font-display text-3xl font-semibold text-brand-black mb-8 text-center">Meus Princípios</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="bg-light-gray p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow">
                <HandRaisedIcon className="w-16 h-16 text-brand-gold mx-auto mb-4" />
                <h3 className="font-display text-xl font-semibold text-brand-black mb-2">Compromisso</h3>
                <p className="text-medium-gray text-sm">
                  Dedicação total em orientar e conectar meus clientes às melhores soluções e especialistas, garantindo que seus direitos sejam compreendidos e defendidos.
                </p>
              </div>
              <div className="bg-light-gray p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow">
                <SparklesIcon className="w-16 h-16 text-brand-gold mx-auto mb-4" />
                <h3 className="font-display text-xl font-semibold text-brand-black mb-2">Personalização</h3>
                <p className="text-medium-gray text-sm">
                  Cada caso é único. Ofereço uma assessoria jurídica personalizada, entendendo as necessidades individuais para fornecer o direcionamento mais eficaz.
                </p>
              </div>
              <div className="bg-light-gray p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow">
                <ShieldCheckIcon className="w-16 h-16 text-brand-gold mx-auto mb-4" />
                <h3 className="font-display text-xl font-semibold text-brand-black mb-2">Ética e Transparência</h3>
                <p className="text-medium-gray text-sm">
                 Atuação pautada pela ética profissional e total transparência em todas as etapas do processo de intermediação e assessoria.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center py-12 bg-brand-black text-brand-white rounded-lg shadow-xl">
            <h3 className="font-display text-2xl font-semibold text-brand-gold mb-4">Pronto para dar o próximo passo?</h3>
            <p className="max-w-xl mx-auto mb-6">
              Se você busca clareza, direcionamento e acesso a serviços jurídicos de qualidade, estou aqui para ajudar.
            </p>
            <a 
                href="#/contato"
                className="bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-6 rounded-lg shadow-md transition-colors"
            >
                Fale Comigo
            </a>
          </div>

        </div>
      </section>
    </>
  );
};

export default AboutPage;