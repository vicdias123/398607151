import React from 'react';
import { useParams, Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import { ARTICLES_DATA, LAWYERS_DATA, COMPANY_NAME } from '../constants';
import { Article } from '../types'; 
import { UserCircleIcon, CalendarDaysIcon, ClockIcon, TagIcon } from '@heroicons/react/24/outline';

const ArticlePage: React.FC = () => {
  const { articleSlug } = useParams<{ articleSlug: string }>();
  const article = ARTICLES_DATA.find(a => a.slug === articleSlug);
  
  if (!article) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="font-display text-3xl font-bold text-brand-black mb-4">Artigo não encontrado.</h1>
        <Link to="/blog" className="text-brand-gold hover:underline">
          Voltar para o blog
        </Link>
      </div>
    );
  }

  const author = LAWYERS_DATA.find(l => l.id === article.authorId);
  const relatedArticles = ARTICLES_DATA.filter(
    relArt => relArt.category === article.category && relArt.id !== article.id
  ).slice(0, 2);

  return (
    <>
      <PageHeader 
        title={article.title}
        imageUrl={article.imageUrl || `https://picsum.photos/seed/articlepage-${article.id}/1920/400`}
      />
      <div className="py-16 bg-brand-white font-sans">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            {/* Article Meta */}
            <div className="mb-8 text-sm text-medium-gray flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-gray-200 pb-4">
              <div className="flex items-center">
                <UserCircleIcon className="w-5 h-5 mr-1.5 text-brand-gold" />
                {author ? (
                  <Link to={`/equipe/${author.id}`} className="hover:text-brand-gold">{author.name}</Link>
                ) : (
                  'Autor Desconhecido'
                )}
              </div>
              <div className="flex items-center">
                <CalendarDaysIcon className="w-5 h-5 mr-1.5 text-brand-gold" />
                {article.date}
              </div>
              <div className="flex items-center">
                <ClockIcon className="w-5 h-5 mr-1.5 text-brand-gold" />
                {article.estimatedReadTime} de leitura
              </div>
              <div className="flex items-center">
                <TagIcon className="w-5 h-5 mr-1.5 text-brand-gold" />
                {/* Alterado para não usar o state, o filtro na página do blog fará isso */}
                <span className="text-medium-gray">{article.category}</span>
              </div>
            </div>

            {/* Article Content */}
            <article className="prose prose-lg max-w-none text-dark-gray leading-relaxed"
                     dangerouslySetInnerHTML={{ __html: article.content }} />

            {/* Tags */}
            {article.tags && article.tags.length > 0 && (
              <div className="mt-10 pt-6 border-t border-gray-200">
                <h4 className="text-sm font-semibold text-brand-black mb-2">Tags:</h4>
                <div className="flex flex-wrap gap-2">
                  {article.tags.map(tag => (
                    <span key={tag} className="bg-brand-light-gold bg-opacity-30 text-brand-gold text-xs font-medium px-2.5 py-1 rounded-full">{tag}</span>
                  ))}
                </div>
              </div>
            )}
            
            {author && (
              <div className="mt-12 p-6 bg-light-gray rounded-lg flex items-start gap-4 border border-gray-200">
                <img src={author.photoUrl} alt={author.name} className="w-20 h-20 rounded-full object-cover border-2 border-brand-gold"/>
                <div>
                  <p className="text-xs text-medium-gray uppercase">Sobre o Autor</p>
                  <h4 className="font-display text-lg font-semibold text-brand-black mb-1">
                    <Link to={`/equipe/${author.id}`} className="hover:text-brand-gold">{author.name}</Link>
                  </h4>
                  <p className="text-sm text-medium-gray line-clamp-3">{author.bio.length > 150 ? author.bio.substring(0, 150) + '...' : author.bio}</p>
                </div>
              </div>
            )}

            {relatedArticles.length > 0 && (
              <div className="mt-16">
                <h3 className="font-display text-2xl font-bold text-brand-black mb-6">Artigos Relacionados</h3>
                <div className="grid md:grid-cols-2 gap-8">
                  {relatedArticles.map(relArt => (
                     <div key={relArt.id} className="bg-brand-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow">
                      <Link to={`/blog/${relArt.slug}`}>
                        <img src={relArt.imageUrl} alt={relArt.title} className="w-full h-40 object-cover"/>
                      </Link>
                      <div className="p-4">
                        <p className="text-xs text-brand-gold uppercase mb-1 font-sans">{relArt.category}</p>
                        <Link to={`/blog/${relArt.slug}`} className="hover:text-brand-gold">
                           <h4 className="font-display text-md font-semibold text-brand-black mb-1 line-clamp-2">{relArt.title}</h4>
                        </Link>
                        <p className="text-xs text-medium-gray font-sans">{relArt.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="mt-16 text-center p-8 bg-brand-black text-brand-white rounded-lg shadow-xl">
                <h3 className="font-display text-2xl font-semibold text-brand-gold mb-3">Precisa de Ajuda com este Assunto?</h3>
                <p className="mb-6 text-brand-light-gold font-sans">Minha assessoria pode fornecer o direcionamento jurídico que você precisa.</p>
                <Link 
                    to="/contato"
                    className="inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-8 rounded-lg shadow-md transition-colors"
                >
                    Fale Comigo
                </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ArticlePage;