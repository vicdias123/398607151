
import React from 'react';
import { Link } from 'react-router-dom';
import { ExclamationTriangleIcon } from '@heroicons/react/24/outline';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] text-center px-4 py-16 bg-white">
      <ExclamationTriangleIcon className="w-24 h-24 text-secondary mb-6" />
      <h1 className="text-5xl md:text-6xl font-extrabold text-primary mb-4">404</h1>
      <h2 className="text-2xl md:text-3xl font-semibold text-dark-gray mb-6">Página Não Encontrada</h2>
      <p className="text-lg text-medium-gray mb-10 max-w-md">
        Oops! Parece que a página que você está procurando não existe ou foi movida.
      </p>
      <Link
        to="/"
        className="bg-primary hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg shadow-md transition-colors duration-300 text-lg"
      >
        Voltar para a Página Inicial
      </Link>
    </div>
  );
};

export default NotFoundPage;
