import React from 'react';
import PageHeader from '../components/PageHeader';
import LawyerCard from '../components/LawyerCard';
import { LAWYERS_DATA, COMPANY_NAME } from '../constants';
import { Link } from 'react-router-dom';

const TeamPage: React.FC = () => {
  // Como agora é focado em Vitor Dias Barbosa, exibimos apenas ele.
  const mainProfile = LAWYERS_DATA[0];

  return (
    <>
      <PageHeader 
        title={COMPANY_NAME} // Ou "Conheça Vitor Dias Barbosa"
        subtitle="Assessor jurídico dedicado a oferecer soluções personalizadas e eficazes."
        imageUrl="https://picsum.photos/seed/teamvdb/1920/400"
      />

      <section className="py-16 bg-brand-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {mainProfile ? (
             <div className="max-w-lg mx-auto bg-light-gray p-8 rounded-xl shadow-xl">
                <img 
                  src={mainProfile.photoUrl} 
                  alt={mainProfile.name} 
                  className="w-48 h-48 rounded-full mx-auto mb-6 object-cover border-4 border-brand-gold"
                />
                <h2 className="font-display text-3xl font-semibold text-brand-black text-center mb-2">{mainProfile.name}</h2>
                <p className="text-brand-gold text-center font-medium mb-4">{mainProfile.specialties.join(' | ')}</p>
                <p className="text-medium-gray text-center leading-relaxed mb-6">
                    {mainProfile.bio.length > 200 ? mainProfile.bio.substring(0, 200) + "..." : mainProfile.bio }
                </p>
                <div className="text-center">
                    <Link
                        to={`/equipe/${mainProfile.id}`}
                        className="inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-6 rounded-lg shadow-md transition-colors"
                    >
                        Ver Perfil Completo
                    </Link>
                </div>
            </div>
          ) : (
            <p className="text-center text-medium-gray">Informações sobre o profissional em breve.</p>
          )}
        </div>
      </section>
    </>
  );
};

export default TeamPage;