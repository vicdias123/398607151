
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import PracticeAreasPage from './pages/PracticeAreasPage';
import SinglePracticeAreaPage from './pages/SinglePracticeAreaPage';
import TeamPage from './pages/TeamPage';
import LawyerProfilePage from './pages/LawyerProfilePage';
import BlogPage from './pages/BlogPage';
import ArticlePage from './pages/ArticlePage';
import ContactPage from './pages/ContactPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsOfUsePage from './pages/TermsOfUsePage';
import FAQPage from './pages/FAQPage';
import NotFoundPage from './pages/NotFoundPage';
import WhatsAppWidget from './components/WhatsAppWidget';
import ChatbotWidget from './components/ChatbotWidget';
import useScrollToTop from './hooks/useScrollToTop';

const App: React.FC = () => {
  return (
    <HashRouter>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/sobre" element={<AboutPage />} />
            <Route path="/areas-atuacao" element={<PracticeAreasPage />} />
            <Route path="/areas-atuacao/:areaId" element={<SinglePracticeAreaPage />} />
            <Route path="/equipe" element={<TeamPage />} />
            <Route path="/equipe/:lawyerId" element={<LawyerProfilePage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:articleSlug" element={<ArticlePage />} />
            <Route path="/contato" element={<ContactPage />} />
            <Route path="/politica-de-privacidade" element={<PrivacyPolicyPage />} />
            <Route path="/termos-de-uso" element={<TermsOfUsePage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
        <WhatsAppWidget />
        <ChatbotWidget />
      </div>
    </HashRouter>
  );
};

// Helper component to ensure useScrollToTop is called within Router context
const ScrollToTop: React.FC = () => {
  useScrollToTop();
  return null;
}

export default App;
