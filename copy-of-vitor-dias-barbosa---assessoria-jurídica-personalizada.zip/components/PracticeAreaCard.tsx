import React from 'react';
import { Link } from 'react-router-dom';
import { PracticeArea } from '../types';

interface PracticeAreaCardProps {
  area: PracticeArea;
}

const PracticeAreaCard: React.FC<PracticeAreaCardProps> = ({ area }) => {
  return (
    <div className="bg-brand-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col h-full border border-gray-200">
      <div className="p-6 flex-grow">
        <div className="flex items-center justify-center mb-4 text-brand-gold w-16 h-16 mx-auto bg-brand-light-gold bg-opacity-30 rounded-full">
          {React.cloneElement(area.icon as React.ReactElement<{ className?: string }>, { className: "w-8 h-8" })}
        </div>
        <h3 className="font-display text-xl font-semibold text-brand-black mb-2 text-center">{area.name}</h3>
        <p className="text-medium-gray text-sm text-center leading-relaxed line-clamp-3 font-sans">{area.descriptionShort}</p>
      </div>
      <div className="p-6 bg-gray-50 text-center mt-auto">
        <Link
          to={`/areas-atuacao/${area.slug}`}
          className="text-brand-gold hover:text-opacity-80 font-semibold transition-colors duration-300 text-sm font-sans"
        >
          Saiba Mais <i className="fas fa-arrow-right ml-1"></i>
        </Link>
      </div>
    </div>
  );
};

export default PracticeAreaCard;