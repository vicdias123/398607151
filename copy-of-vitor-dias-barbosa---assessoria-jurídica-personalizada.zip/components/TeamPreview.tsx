
import React from 'react';
import { Link } from 'react-router-dom';
import { LAWYERS_DATA } from '../constants';
import LawyerCard from './LawyerCard';

const TeamPreview: React.FC = () => {
  const previewLawyers = LAWYERS_DATA.slice(0, 3); // Show first 3 lawyers

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-dark-gray mb-4">Conheça Nossa Equipe</h2>
          <p className="text-lg text-medium-gray max-w-2xl mx-auto">
            Profissionais dedicados e experientes, prontos para oferecer a melhor assessoria jurídica.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {previewLawyers.map(lawyer => (
            <LawyerCard key={lawyer.id} lawyer={lawyer} />
          ))}
        </div>
        <div className="text-center mt-12">
          <Link
            to="/equipe"
            className="bg-secondary hover:bg-amber-600 text-white font-semibold py-3 px-8 rounded-lg shadow-md transform hover:scale-105 transition-all duration-300"
          >
            Ver Equipe Completa
          </Link>
        </div>
      </div>
    </section>
  );
};

export default TeamPreview;
