
import React from 'react';
import { Link } from 'react-router-dom';
import { Lawyer } from '../types';

interface LawyerCardProps {
  lawyer: Lawyer;
}

const LawyerCard: React.FC<LawyerCardProps> = ({ lawyer }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden text-center hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
      <img 
        src={lawyer.photoUrl} 
        alt={lawyer.name} 
        className="w-full h-56 object-cover" 
      />
      <div className="p-6 flex-grow flex flex-col">
        <h3 className="text-xl font-semibold text-primary mb-1">{lawyer.name}</h3>
        <p className="text-secondary text-sm font-medium mb-2">{lawyer.specialties.join(' | ')}</p>
        <p className="text-medium-gray text-sm leading-relaxed line-clamp-3 mb-4 flex-grow">
          {lawyer.bio.substring(0, 100)}{lawyer.bio.length > 100 ? '...' : ''}
        </p>
        <div className="mt-auto">
          <Link
            to={`/equipe/${lawyer.id}`}
            className="inline-block bg-primary hover:bg-blue-700 text-white text-sm font-semibold py-2 px-4 rounded-md transition-colors duration-300"
          >
            Ver Perfil Completo
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LawyerCard;
