import React from 'react';
import { Link } from 'react-router-dom';
import { COMPANY_NAME, LAWYERS_DATA, COMPANY_DESCRIPTION_INTERMEDIATOR } from '../constants';

const AboutMeSummary: React.FC = () => {
  const lawyer = LAWYERS_DATA[0];
  const summaryText = COMPANY_DESCRIPTION_INTERMEDIATOR.substring(0, 200) + "...";


  return (
    <section className="py-16 bg-brand-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-black mb-4">
            Conheça {COMPANY_NAME}
          </h2>
          <p className="text-lg text-medium-gray max-w-2xl mx-auto">
            Como intermediador jurídico, meu compromisso é conectar você às soluções legais mais adequadas, com um atendimento personalizado e eficiente.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src={lawyer.photoUrl} 
              alt={COMPANY_NAME}
              className="rounded-lg shadow-xl w-full h-auto object-cover max-w-md mx-auto border-2 border-brand-gold"
            />
          </div>
          <div className="text-medium-gray leading-relaxed prose prose-lg">
            <p className="mb-4 text-lg">
             {summaryText}
            </p>
            <p className="mb-6 text-lg">
              Com uma abordagem focada na clareza e na estratégia, busco simplificar o universo jurídico para meus clientes.
            </p>
            <Link
              to="/sobre"
              className="inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-6 rounded-lg shadow-md transform hover:scale-105 transition-all duration-300 no-underline"
            >
              Saiba Mais Sobre Mim
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutMeSummary;