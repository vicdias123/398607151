import React from 'react';
import { Link } from 'react-router-dom';
import { Article, Lawyer } from '../types';
import { LAWYERS_DATA } from '../constants';

interface ArticleCardProps {
  article: Article;
}

const ArticleCard: React.FC<ArticleCardProps> = ({ article }) => {
  const author = LAWYERS_DATA.find(l => l.id === article.authorId);

  return (
    <div className="bg-brand-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col h-full border border-gray-200">
      <Link to={`/blog/${article.slug}`}>
        <img 
          src={article.imageUrl} 
          alt={article.title} 
          className="w-full h-48 object-cover"
        />
      </Link>
      <div className="p-6 flex-grow flex flex-col">
        <p className="text-brand-gold text-xs font-semibold uppercase mb-1 font-sans">{article.category}</p>
        <Link to={`/blog/${article.slug}`} className="hover:text-brand-gold transition-colors">
          <h3 className="font-display text-lg font-semibold text-brand-black mb-2 line-clamp-2">{article.title}</h3>
        </Link>
        <p className="text-medium-gray text-sm leading-relaxed line-clamp-3 mb-3 flex-grow font-sans">{article.summary}</p>
        <div className="text-xs text-medium-gray mt-auto font-sans">
          <span>{author ? author.name : 'Autor Desconhecido'}</span> &bull; <span>{article.date}</span> &bull; <span>{article.estimatedReadTime}</span>
        </div>
      </div>
       <div className="p-6 bg-gray-50 text-left">
        <Link
          to={`/blog/${article.slug}`}
          className="text-brand-gold hover:text-opacity-80 font-semibold transition-colors duration-300 text-sm font-sans"
        >
          Leia Mais <i className="fas fa-arrow-right ml-1"></i>
        </Link>
      </div>
    </div>
  );
};

export default ArticleCard;