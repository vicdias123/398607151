import React from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  imageUrl?: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle, imageUrl }) => {
  const bgStyle = imageUrl 
    ? { backgroundImage: `linear-gradient(rgba(15, 12, 15, 0.7), rgba(15, 12, 15, 0.7)), url(${imageUrl})` } 
    : {};

  return (
    <div 
      className={`py-20 md:py-28 ${imageUrl ? 'bg-cover bg-center bg-no-repeat' : 'bg-brand-black'}`} 
      style={bgStyle}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <h1 className="font-display text-4xl md:text-5xl font-semibold text-brand-gold mb-4">{title}</h1>
        {subtitle && <p className="font-sans text-lg md:text-xl text-brand-white max-w-3xl mx-auto">{subtitle}</p>}
      </div>
    </div>
  );
};

export default PageHeader;