import React from 'react';
import { WHATSAPP_NUMBER } from '../constants';

const WhatsAppWidget: React.FC = () => {
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Olá! Gostaria de mais informações sobre sua assessoria jurídica.")}`;

  return (
    <a
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg z-40 transition-transform transform hover:scale-110"
      aria-label="Fale conosco pelo WhatsApp"
    >
      <i className="fab fa-whatsapp fa-2x"></i>
    </a>
  );
};

export default WhatsAppWidget;