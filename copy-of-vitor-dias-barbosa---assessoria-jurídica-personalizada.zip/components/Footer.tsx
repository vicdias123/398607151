
import React from 'react';
import { Link } from 'react-router-dom';
import { 
    COMPANY_NAME, 
    COMPANY_ADDRESS, 
    COMPANY_PHONE, 
    COMPANY_EMAIL, 
    NAV_LINKS, 
    COMPANY_INSTAGRAM_URL, 
    COMPANY_LOGO_URL_DARK_BG, // Importa URL da imagem
    LAWYERS_DATA 
} from '../constants';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  const additionalLinks = [
    { label: 'Política de Privacidade', path: '/politica-de-privacidade' },
    { label: 'Termos de Uso', path: '/termos-de-uso' },
    { label: 'FAQ', path: '/faq' },
  ];

  return (
    <footer className="bg-brand-black text-brand-light-gold pt-16 pb-8 font-sans">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-10">
          {/* Column 1: Logo and Address */}
          <div>
            <Link to="/" className="block mb-4" aria-label="Página Inicial">
              <img 
                src={COMPANY_LOGO_URL_DARK_BG} 
                alt={`${COMPANY_NAME} Logo`} 
                className="h-12 md:h-14 w-auto mb-4" // Ajuste a altura e margem conforme necessário
              />
            </Link>
            <p className="text-sm leading-relaxed mb-2">
              {COMPANY_ADDRESS}
            </p>
            <p className="text-sm">Telefone: <a href={`tel:${COMPANY_PHONE.replace(/\D/g,'')}`} className="hover:text-brand-gold">{COMPANY_PHONE}</a></p>
            <p className="text-sm">Email: <a href={`mailto:${COMPANY_EMAIL}`} className="hover:text-brand-gold">{COMPANY_EMAIL}</a></p>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h5 className="text-xl font-display font-semibold text-brand-gold mb-4">Navegação</h5>
            <ul className="space-y-2">
              {NAV_LINKS.filter(link => !link.subItems).map(link => ( 
                <li key={link.path}>
                  <Link to={link.path} className="hover:text-brand-gold transition-colors duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
               <li>
                  <Link to="/areas-atuacao" className="hover:text-brand-gold transition-colors duration-300 text-sm">
                    Áreas de Suporte
                  </Link>
                </li>
            </ul>
          </div>

          {/* Column 3: Additional Info */}
          <div>
            <h5 className="text-xl font-display font-semibold text-brand-gold mb-4">Informações</h5>
            <ul className="space-y-2">
                {additionalLinks.map(link => (
                   <li key={link.path}>
                     <Link to={link.path} className="hover:text-brand-gold transition-colors duration-300 text-sm">
                       {link.label}
                     </Link>
                   </li>
                ))}
            </ul>
          </div>

          {/* Column 4: Social Media & Hours */}
          <div>
            <h5 className="text-xl font-display font-semibold text-brand-gold mb-4">Siga-me</h5>
            <div className="flex space-x-4 mb-4">
              <a href={COMPANY_INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="text-brand-light-gold hover:text-brand-gold transition-colors duration-300" aria-label="Instagram">
                <i className="fab fa-instagram fa-2x"></i>
              </a>
              <a href={LAWYERS_DATA[0].linkedin || "#"} target="_blank" rel="noopener noreferrer" className="text-brand-light-gold hover:text-brand-gold transition-colors duration-300" aria-label="LinkedIn">
                <i className="fab fa-linkedin fa-2x"></i>
              </a>
            </div>
            <h5 className="text-lg font-display font-semibold text-brand-gold mb-2">Atendimento</h5>
            <p className="text-sm">
              Segunda a Sexta: 09:00 - 18:00
            </p>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 mt-8 text-center">
          <p className="text-sm">
            &copy; {currentYear} {COMPANY_NAME}. Todos os direitos reservados.
          </p>
           {/* <p className="text-xs mt-1">
            Desenvolvido com <i className="fas fa-heart text-brand-gold"></i>
          </p> */}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
