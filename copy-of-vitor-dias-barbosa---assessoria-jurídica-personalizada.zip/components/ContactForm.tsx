import React, { useState } from 'react';
import { PRACTICE_AREAS_DATA } from '../constants';

interface ContactFormProps {
  isDetailed?: boolean; 
}

const ContactForm: React.FC<ContactFormProps> = ({ isDetailed = false }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    personType: 'fisica',
    areaOfInterest: '',
    urgency: 'media',
    file: null as File | null,
    lgpdConsent: false,
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      setFormData(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else if (type === 'file') {
        setFormData(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).files?.[0] || null }));
    }
    else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitError(null);
    
    if (isDetailed && !formData.lgpdConsent) {
        setSubmitError("Você deve concordar com a Política de Privacidade.");
        return;
    }

    console.log('Form data submitted:', formData);
    await new Promise(resolve => setTimeout(resolve, 1000));

    setIsSubmitted(true);
    setTimeout(() => {
        setFormData({
            name: '', email: '', phone: '', subject: '', message: '',
            personType: 'fisica', areaOfInterest: '', urgency: 'media', file: null, lgpdConsent: false
        });
        setIsSubmitted(false);
    }, 5000);
  };
  
  if (isSubmitted) {
    return (
      <div className="bg-green-50 border-l-4 border-green-500 text-green-700 p-6 rounded-md shadow-md font-sans" role="alert">
        <h3 className="font-bold text-lg mb-2">Mensagem Enviada com Sucesso!</h3>
        <p>Obrigado por entrar em contato. Retornarei o mais breve possível.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-brand-white p-8 rounded-lg shadow-xl border border-gray-200 font-sans">
      {submitError && (
        <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
            <p>{submitError}</p>
        </div>
      )}
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-brand-black">Nome Completo <span className="text-red-500">*</span></label>
        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required 
               className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm" />
      </div>
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-brand-black">Email <span className="text-red-500">*</span></label>
        <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required
               className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm" />
      </div>
      
      {isDetailed && (
        <>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-brand-black">Telefone</label>
            <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} placeholder="(XX) XXXXX-XXXX"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm" />
          </div>
          <div>
            <label htmlFor="personType" className="block text-sm font-medium text-brand-black">Tipo de Pessoa</label>
            <select name="personType" id="personType" value={formData.personType} onChange={handleChange}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm bg-white">
              <option value="fisica">Pessoa Física</option>
              <option value="juridica">Pessoa Jurídica</option>
            </select>
          </div>
          <div>
            <label htmlFor="areaOfInterest" className="block text-sm font-medium text-brand-black">Área de Interesse <span className="text-red-500">*</span></label>
            <select name="areaOfInterest" id="areaOfInterest" value={formData.areaOfInterest} onChange={handleChange} required
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm bg-white">
              <option value="">Selecione uma área</option>
              {PRACTICE_AREAS_DATA.map(area => (
                <option key={area.slug} value={area.slug}>{area.name}</option>
              ))}
              <option value="outro">Outro Assunto</option>
            </select>
          </div>
           <div>
            <label htmlFor="urgency" className="block text-sm font-medium text-brand-black">Urgência do Caso</label>
            <select name="urgency" id="urgency" value={formData.urgency} onChange={handleChange}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm bg-white">
              <option value="baixa">Baixa</option>
              <option value="media">Média</option>
              <option value="alta">Alta</option>
            </select>
          </div>
        </>
      )}

      <div>
        <label htmlFor="subject" className="block text-sm font-medium text-brand-black">Assunto {isDetailed ? '' : <span className="text-red-500">*</span>}</label>
        <input type="text" name="subject" id="subject" value={formData.subject} onChange={handleChange} required={!isDetailed}
               className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm" />
      </div>

      <div>
        <label htmlFor="message" className="block text-sm font-medium text-brand-black">Sua Mensagem <span className="text-red-500">*</span></label>
        <textarea name="message" id="message" rows={isDetailed ? 5 : 3} value={formData.message} onChange={handleChange} required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm"></textarea>
      </div>

      {isDetailed && (
        <>
          <div>
            <label htmlFor="file" className="block text-sm font-medium text-brand-black">Anexar Documento (Opcional, máx. 5MB)</label>
            <input type="file" name="file" id="file" onChange={handleChange} accept=".pdf,.doc,.docx,.jpg,.png"
                  className="mt-1 block w-full text-sm text-medium-gray file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-brand-gold file:text-brand-black hover:file:bg-opacity-80"/>
          </div>
          <div className="flex items-start">
            <div className="flex items-center h-5">
              <input id="lgpdConsent" name="lgpdConsent" type="checkbox" checked={formData.lgpdConsent} onChange={handleChange} required
                     className="focus:ring-brand-gold h-4 w-4 text-brand-gold border-gray-300 rounded" />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="lgpdConsent" className="font-medium text-brand-black">Concordo com a <a href="#/politica-de-privacidade" target="_blank" className="text-brand-gold hover:underline">Política de Privacidade</a> <span className="text-red-500">*</span></label>
              <p className="text-medium-gray text-xs">Seus dados serão usados apenas para entrarmos em contato.</p>
            </div>
          </div>
        </>
      )}

      <div>
        <button type="submit" 
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-brand-black bg-brand-gold hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-gold transition-colors duration-300">
          Enviar Mensagem
        </button>
      </div>
    </form>
  );
};

export default ContactForm;