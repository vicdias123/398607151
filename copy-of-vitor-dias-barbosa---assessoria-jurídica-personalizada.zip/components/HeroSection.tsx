import React from 'react';
import { Link } from 'react-router-dom';
import { COMPANY_NAME, COMPANY_SLOGAN } from '../constants';

const HeroSection: React.FC = () => {
  return (
    <div className="relative bg-brand-black text-brand-white py-24 md:py-40 overflow-hidden">
      <div className="absolute inset-0 opacity-5">
         {/* Subtle pattern could be SVG or a very faint image if desired */}
      </div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center">
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-semibold leading-tight mb-6 text-brand-gold">
            {COMPANY_NAME}
          </h1>
          <p className="font-sans text-lg sm:text-xl md:text-2xl text-brand-light-gold mb-10 max-w-3xl mx-auto">
            {COMPANY_SLOGAN}
          </p>
          <div className="space-y-4 sm:space-y-0 sm:space-x-4">
            <Link
              to="/contato"
              className="inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300 text-lg"
            >
              Entre em Contato
            </Link>
            <Link
              to="/areas-atuacao"
              className="inline-block bg-transparent hover:bg-brand-gold hover:text-brand-black border-2 border-brand-gold text-brand-gold font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300 text-lg"
            >
              Nossas Áreas de Suporte
            </Link>
          </div>
        </div>
      </div>
      {/* Decorative elements using brand colors */}
      <div className="absolute top-0 left-0 w-32 h-32 md:w-64 md:h-64 bg-brand-gold opacity-10 rounded-full transform -translate-x-1/3 -translate-y-1/3"></div>
      <div className="absolute bottom-0 right-0 w-32 h-32 md:w-64 md:h-64 bg-brand-light-gold opacity-5 rounded-full transform translate-x-1/3 translate-y-1/3"></div>
    </div>
  );
};

export default HeroSection;