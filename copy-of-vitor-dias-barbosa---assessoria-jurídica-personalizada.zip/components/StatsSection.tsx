import React from 'react';
import { OFFICE_STATS_DATA } from '../constants';
import StatsCard from './StatsCard';
import { CheckBadgeIcon, UserGroupIcon, CalendarDaysIcon } from '@heroicons/react/24/outline';

const StatsSection: React.FC = () => {
  return (
    <section className="py-16 bg-brand-black text-brand-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-gold mb-4">Minha Experiência em Números</h2>
          <p className="text-lg text-brand-light-gold max-w-2xl mx-auto font-sans">
            Resultados que refletem meu compromisso e a confiança depositada.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <StatsCard 
            icon={<CheckBadgeIcon />} 
            value={OFFICE_STATS_DATA.casesWon.toLocaleString('pt-BR') + "+"}
            label="Casos Direcionados com Sucesso" 
          />
          <StatsCard 
            icon={<UserGroupIcon />} 
            value={OFFICE_STATS_DATA.clientsSatisfied.toLocaleString('pt-BR') + "+"}
            label="Clientes Satisfeitos" 
          />
          <StatsCard 
            icon={<CalendarDaysIcon />} 
            value={OFFICE_STATS_DATA.yearsExperience + "+"}
            label="Anos de Experiência no Setor" 
          />
        </div>
      </div>
    </section>
  );
};

export default StatsSection;