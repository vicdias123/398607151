import React from 'react';
import { OAB_LOGO_URL } from '../constants'; // Removido OTHER_CERTIFICATION_URL, pois é menos relevante para um profissional individual

const CertificationsSection: React.FC = () => {
  return (
    <section className="py-12 bg-brand-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="font-display text-2xl md:text-3xl font-semibold text-brand-black mb-3">Compromisso Profissional</h2>
          <p className="text-md text-medium-gray max-w-xl mx-auto font-sans">
            Atuação pautada pela ética e pelas normativas da Ordem dos Advogados do Brasil.
          </p>
        </div>
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
          <div className="flex flex-col items-center">
            <img src={OAB_LOGO_URL} alt="Selo OAB" className="h-20 md:h-24 object-contain"/>
            <p className="text-xs text-medium-gray mt-2 font-sans">Inscrição OAB/SP</p>
          </div>
          {/* Pode-se adicionar um placeholder para "Selo de Qualidade em Assessoria" ou similar se desejado */}
           <div className="flex flex-col items-center">
            <div className="w-36 h-20 md:w-40 md:h-24 flex items-center justify-center bg-gray-100 rounded">
                 <span className="text-brand-gold font-display text-sm">Assessoria<br/>Qualificada</span>
            </div>
            <p className="text-xs text-medium-gray mt-2 font-sans">Foco no Cliente</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CertificationsSection;