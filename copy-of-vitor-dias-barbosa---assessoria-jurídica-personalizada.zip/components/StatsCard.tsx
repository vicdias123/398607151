import React from 'react';

interface StatsCardProps {
  icon: React.ReactElement;
  value: string | number;
  label: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ icon, value, label }) => {
  // Este card será usado em um fundo escuro (brand-black)
  // Então, os textos devem ser claros e o ícone/valor podem usar as cores de destaque.
  return (
    <div className="bg-brand-black p-6 rounded-lg shadow-lg text-center border border-brand-gold border-opacity-30">
      <div className="text-brand-gold text-4xl mb-3">
        {React.cloneElement(icon as React.ReactElement<{ className?: string }>, { className: "w-12 h-12 mx-auto" })}
      </div>
      <p className="font-display text-4xl font-semibold text-brand-light-gold mb-1">{value}</p>
      <p className="text-brand-gold opacity-80 font-sans">{label}</p>
    </div>
  );
};

export default StatsCard;