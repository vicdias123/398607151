import React from 'react';
import { COMPANY_ADDRESS } from '../constants';

const MapSection: React.FC = () => {
  const mapQuery = encodeURIComponent(COMPANY_ADDRESS);
  const mapUrl = `https://maps.google.com/maps?q=${mapQuery}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

  return (
    <section className="py-16 bg-light-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-black mb-4">Minha Localização</h2>
          <p className="text-lg text-medium-gray max-w-2xl mx-auto font-sans">
            Encontre-me no coração de São Paulo para uma assessoria jurídica personalizada.
          </p>
        </div>
        <div className="aspect-w-16 aspect-h-9 rounded-lg shadow-xl overflow-hidden border-2 border-brand-gold">
          <iframe
            src={mapUrl}
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Localização do Escritório"
          ></iframe>
        </div>
        <p className="text-center mt-6 text-medium-gray font-sans">{COMPANY_ADDRESS}</p>
      </div>
    </section>
  );
};

export default MapSection;