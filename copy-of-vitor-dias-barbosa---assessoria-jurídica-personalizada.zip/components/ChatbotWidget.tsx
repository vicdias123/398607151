import React, { useState, useEffect, useRef } from 'react';
import { PaperAirplaneIcon, ChatBubbleLeftEllipsisIcon, XMarkIcon } from '@heroicons/react/24/solid';
import { ChatMessage } from '../types';
import { initializeChat, sendMessageToChatbot } from '../services/geminiService';
import { COMPANY_NAME } from '../constants';

const ChatbotWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const [isChatReady, setIsChatReady] = useState(false);

  const getGreetingMessage = (): ChatMessage => ({
    id: Date.now().toString(),
    text: `Olá! Sou o assistente virtual de ${COMPANY_NAME}. Como posso ajudar?`,
    sender: 'bot',
    timestamp: new Date()
  });

  useEffect(() => {
    const initAndGreet = async () => {
      try {
        await initializeChat();
        setIsChatReady(true);
        if (messages.length === 0) {
          setMessages([getGreetingMessage()]);
        }
      } catch (err) {
        console.error("Erro ao inicializar o chat ao abrir:", err);
        setError("Não foi possível iniciar o chatbot. Verifique sua conexão ou tente novamente mais tarde.");
        setIsChatReady(false);
      }
    };

    if (isOpen && !isChatReady) {
      initAndGreet();
    }
  }, [isOpen, isChatReady, messages.length]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
    if (!isOpen) { 
      setError(null); 
      if (!isChatReady) { 
        initializeChat().then(() => {
            setIsChatReady(true);
            if (messages.length === 0) { 
                 setMessages([getGreetingMessage()]);
            }
        }).catch(err => {
            console.error("Erro ao inicializar o chat ao alternar:", err);
            setError("Chatbot indisponível no momento. Tente mais tarde.");
            setIsChatReady(false);
        });
      }
    }
  };

  const handleSendMessage = async () => {
    if (inputValue.trim() === '' || isLoading) return;

    if (!isChatReady) {
      setError("O chatbot não está pronto. Por favor, aguarde a inicialização ou tente reabrir o chat.");
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    const currentInputValue = inputValue;
    setInputValue('');
    setIsLoading(true);
    setError(null);

    try {
      const botResponseText = await sendMessageToChatbot(currentInputValue);
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: botResponseText,
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err) { 
      console.error("Erro ao enviar mensagem (ChatbotWidget):", err);
      const errorMessageText = "Desculpe, não consegui processar sua mensagem. Tente novamente ou contate-nos diretamente.";
      setError(errorMessageText);
      const errorBotMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: errorMessageText,
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorBotMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {!isOpen && (
        <button
          onClick={toggleChatbot}
          className="fixed bottom-24 right-6 bg-brand-gold hover:bg-opacity-80 text-brand-black p-4 rounded-full shadow-lg z-40 transition-transform transform hover:scale-110"
          aria-label="Abrir chatbot"
        >
          <ChatBubbleLeftEllipsisIcon className="h-6 w-6" />
        </button>
      )}

      {isOpen && (
        <div className="fixed bottom-0 right-0 sm:bottom-8 sm:right-8 w-full sm:w-[380px] h-full sm:h-[70vh] sm:max-h-[550px] bg-brand-white rounded-none sm:rounded-xl shadow-2xl flex flex-col z-50 overflow-hidden border border-gray-300 font-sans">
          {/* Header */}
          <div className="bg-brand-black text-brand-white p-4 flex justify-between items-center">
            <h3 className="font-semibold text-lg font-display text-brand-gold">Assistente Virtual</h3>
            <button onClick={toggleChatbot} className="text-brand-white hover:text-brand-light-gold" aria-label="Fechar chatbot">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-grow p-4 space-y-3 overflow-y-auto bg-gray-50">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-xl shadow ${msg.sender === 'user' ? 'bg-brand-gold text-brand-black rounded-br-none' : 'bg-gray-200 text-dark-gray rounded-bl-none'}`}>
                  <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                  <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-gray-700 text-right' : 'text-gray-500 text-left'}`}>
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                 <div className="max-w-[75%] p-3 rounded-xl bg-gray-200 text-dark-gray rounded-bl-none">
                    <p className="text-sm italic">Digitando...</p>
                 </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          {error && <p className="p-2 text-xs text-red-600 bg-red-100 border-t border-red-200 text-center">{error}</p>}

          {/* Input Area */}
          <div className="border-t border-gray-200 p-3 bg-gray-100">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder={isChatReady ? "Digite sua mensagem..." : "Aguardando chatbot..."}
                className="flex-grow p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-gold focus:border-transparent outline-none text-sm"
                disabled={isLoading || !isChatReady}
                aria-label="Campo de mensagem do chatbot"
              />
              <button
                onClick={handleSendMessage}
                disabled={isLoading || inputValue.trim() === '' || !isChatReady}
                className="bg-brand-gold text-brand-black p-2.5 rounded-lg hover:bg-opacity-80 disabled:bg-gray-400 transition-colors"
                aria-label="Enviar mensagem"
              >
                <PaperAirplaneIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatbotWidget;