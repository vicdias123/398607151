
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { NAV_LINKS, COMPANY_LOGO_URL_DARK_BG, COMPANY_NAME } from '../constants'; // Importa URL da imagem
import type { NavLinkItem } from '../types';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/solid';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const toggleNavbar = () => setIsOpen(!isOpen);
  const closeNavbar = () => {
    setIsOpen(false);
    setOpenDropdown(null); // Fechar dropdowns ao fechar navbar
  }

  const handleDropdownToggle = (label: string) => {
    setOpenDropdown(openDropdown === label ? null : label);
  };
  
  const renderNavLink = (item: NavLinkItem, isMobile: boolean = false) => {
    const activeClassName = "text-brand-gold border-b-2 border-brand-gold";
    const inactiveClassName = "text-brand-white hover:text-brand-gold transition-colors duration-300";
    const mobileInactiveClassName = "text-brand-black hover:text-brand-gold transition-colors duration-300 block py-2 px-4 font-medium";
    const mobileActiveClassName = "text-brand-gold font-semibold block py-2 px-4";

    if (item.subItems) {
      return (
        <div className="relative">
          <button 
            onClick={() => handleDropdownToggle(item.label)} // Sempre permitir clique para dropdown
            className={`${isMobile ? mobileInactiveClassName : inactiveClassName} flex items-center w-full text-left py-2 md:py-0`}
            aria-expanded={openDropdown === item.label}
            aria-controls={`dropdown-${item.label}`}
          >
            {item.label}
            <svg className={`w-4 h-4 ml-1 transform transition-transform duration-200 ${openDropdown === item.label ? 'rotate-180' : ''}`} fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
          {openDropdown === item.label && (
            <div 
              id={`dropdown-${item.label}`}
              className={`${isMobile ? 'pl-4 static bg-transparent' : 'absolute z-20 mt-1 w-64 bg-brand-black border border-brand-gold shadow-lg rounded-md py-1 left-0'}`}
            >
              {item.subItems.map(subItem => (
                <NavLink
                  key={subItem.path}
                  to={subItem.path}
                  onClick={() => {closeNavbar();}} // closeNavbar já lida com setOpenDropdown(null)
                  className={({ isActive }) => 
                    `${isMobile ? (isActive ? mobileActiveClassName : mobileInactiveClassName) : (isActive ? 'block px-4 py-2 text-sm text-brand-gold font-semibold bg-gray-800' : 'block px-4 py-2 text-sm text-brand-white hover:bg-gray-800 hover:text-brand-gold')}`
                  }
                >
                  {subItem.label}
                </NavLink>
              ))}
            </div>
          )}
        </div>
      );
    }

    return (
      <NavLink
        to={item.path}
        onClick={closeNavbar}
        className={({ isActive }) => 
            `${isMobile ? (isActive ? mobileActiveClassName : mobileInactiveClassName) : (isActive ? activeClassName : inactiveClassName)} py-2 md:py-0`
        }
      >
        {item.label}
      </NavLink>
    );
  };

  return (
    <nav className="bg-brand-black shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0">
            <Link to="/" onClick={closeNavbar} aria-label="Página Inicial">
              <img 
                src={COMPANY_LOGO_URL_DARK_BG} 
                alt={`${COMPANY_NAME} Logo`} 
                className="h-12 md:h-14 w-auto" // Ajuste a altura conforme necessário
              />
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6 font-medium">
              {NAV_LINKS.map((item) => (
                <div key={item.label}>{renderNavLink(item)}</div>
              ))}
            </div>
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleNavbar}
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-brand-white hover:text-brand-gold focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-gold"
              aria-controls="mobile-menu"
              aria-expanded={isOpen}
            >
              <span className="sr-only">Abrir menu principal</span>
              {isOpen ? <XMarkIcon className="block h-8 w-8" /> : <Bars3Icon className="block h-8 w-8" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-brand-white border-t border-brand-gold" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {NAV_LINKS.map((item) => (
               <div key={item.label}>{renderNavLink(item, true)}</div>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
