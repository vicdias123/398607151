
import React from 'react';
import { Testimonial } from '../types';

// Fix: Define TestimonialCardProps interface
interface TestimonialCardProps {
  testimonial: Testimonial;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ testimonial }) => {
  return (
    <div className="bg-brand-white p-8 rounded-lg shadow-xl h-full flex flex-col border border-brand-light-gold">
      <div className="flex-grow mb-6">
        <p className="text-dark-gray italic text-lg font-sans">"{testimonial.text}"</p>
      </div>
      <div className="flex items-center mt-auto pt-4 border-t border-gray-200">
        <img 
          src={testimonial.photoUrl} 
          alt={testimonial.clientName} 
          className="w-16 h-16 rounded-full mr-4 object-cover border-2 border-brand-gold"
        />
        <div>
          <p className="font-semibold text-brand-gold text-lg font-display">{testimonial.clientName}</p>
          <p className="text-medium-gray text-sm font-sans">{testimonial.role}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;