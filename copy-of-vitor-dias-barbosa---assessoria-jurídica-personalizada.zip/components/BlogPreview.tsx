import React from 'react';
import { Link } from 'react-router-dom';
import { ARTICLES_DATA } from '../constants';
import ArticleCard from './ArticleCard';

const BlogPreview: React.FC = () => {
  const recentArticles = ARTICLES_DATA.slice(0, 2); // Mostrar 2 artigos no preview

  return (
    <section className="py-16 bg-light-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-black mb-4">Blog Jurídico</h2>
          <p className="text-lg text-medium-gray max-w-2xl mx-auto font-sans">
            Mantenha-se informado com artigos e análises sobre o universo jurídico.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {recentArticles.map(article => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
        {ARTICLES_DATA.length > 2 && (
          <div className="text-center mt-12">
            <Link
              to="/blog"
              className="inline-block bg-brand-gold hover:bg-opacity-80 text-brand-black font-semibold py-3 px-8 rounded-lg shadow-md transform hover:scale-105 transition-all duration-300"
            >
              Ver Todos os Artigos
            </Link>
          </div>
        )}
      </div>
    </section>
  );
};

export default BlogPreview;