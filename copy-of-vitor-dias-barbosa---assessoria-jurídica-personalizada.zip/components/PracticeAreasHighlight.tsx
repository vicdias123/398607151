import React from 'react';
import { PRACTICE_AREAS_DATA } from '../constants';
import PracticeAreaCard from './PracticeAreaCard';

const PracticeAreasHighlight: React.FC = () => {
  const highlightedAreas = PRACTICE_AREAS_DATA.slice(0, 4);

  return (
    <section className="py-16 bg-light-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-brand-black mb-4">Áreas de Suporte</h2>
          <p className="text-lg text-medium-gray max-w-2xl mx-auto font-sans">
            Ofereço orientação e direcionamento especializado em diversas áreas do direito, conectando você às soluções mais adequadas.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlightedAreas.map(area => (
            <PracticeAreaCard key={area.id} area={area} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default PracticeAreasHighlight;