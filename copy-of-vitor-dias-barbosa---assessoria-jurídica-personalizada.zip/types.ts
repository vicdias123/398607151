
import React from 'react';

export interface Lawyer {
  id: string;
  name: string;
  photoUrl: string;
  specialties: string[];
  bio: string;
  education: string[];
  experience: string[];
  oab: string;
  linkedin?: string;
  lattes?: string;
  email: string;
}

export interface PracticeArea {
  id: string;
  slug: string;
  name: string;
  icon: React.ReactElement;
  descriptionShort: string;
  descriptionLong: string;
  services: string[];
  applicableLegislation?: string[];
  faq?: FAQItem[];
  specialistLawyersIds?: string[];
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  text: string;
  photoUrl: string;
  role: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  authorId: string; 
  date: string;
  estimatedReadTime: string;
  summary: string;
  content: string; 
  tags: string[];
  category: string;
  imageUrl: string;
}

export interface OfficeStats {
  casesWon: number;
  clientsSatisfied: number;
  yearsExperience: number;
}

export interface NavLinkItem {
  label: string;
  path: string;
  subItems?: NavLinkItem[];
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}
