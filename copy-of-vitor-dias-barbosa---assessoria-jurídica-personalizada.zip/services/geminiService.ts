import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";
import { COMPANY_NAME, COMPANY_ADDRESS, PRACTICE_AREAS_DATA } from "../constants";

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;
let chat: Chat | null = null;
let isChatInitializationAttempted = false;
let chatInitializationPromise: Promise<void> | null = null;

const initializeSDK = (): void => {
    if (ai) return;
    if (!API_KEY) {
        console.error("Chave API do Google GenAI não configurada em process.env.API_KEY. O Chatbot não funcionará.");
        return;
    }
    try {
        ai = new GoogleGenAI({ apiKey: API_KEY });
    } catch (error) {
        console.error("Falha ao inicializar o SDK GoogleGenAI:", error);
        ai = null; 
    }
};

initializeSDK();

const getPracticeAreasList = () => PRACTICE_AREAS_DATA.map(area => area.name).join(', ');

export const initializeChat = async (): Promise<void> => {
    if (chat) return;
    if (chatInitializationPromise) return chatInitializationPromise;

    isChatInitializationAttempted = true;

    chatInitializationPromise = (async () => {
        if (!ai) {
            initializeSDK();
            if (!ai) {
                console.error("SDK do Gemini AI não está disponível para inicializar o chat.");
                throw new Error("SDK_NAO_INICIALIZADO");
            }
        }
        
        try {
            chat = ai.chats.create({
                model: 'gemini-2.5-flash-preview-04-17',
                config: {
                    systemInstruction: `Você é um assistente virtual de ${COMPANY_NAME}. Vitor Dias Barbosa é um assessor jurídico e intermediador localizado em ${COMPANY_ADDRESS.split('-')[1].trim()}, São Paulo. Ele oferece suporte e direcionamento em diversas áreas do direito, como ${getPracticeAreasList()}. Sua principal função é conectar clientes aos serviços legais de que precisam. Seja prestativo, forneça informações gerais sobre os tipos de suporte oferecidos e como funciona a assessoria. Para conselhos jurídicos específicos ou informações detalhadas sobre casos, recomende enfaticamente que o usuário entre em contato direto com Vitor Dias Barbosa através do formulário de contato ou telefone para uma consulta personalizada. Não forneça conselhos legais diretos. Seja cordial, profissional e use uma linguagem acessível.`,
                },
            });
            console.log(`Chat inicializado com sucesso para ${COMPANY_NAME}.`);
        } catch (error) {
            console.error("Erro ao inicializar o chat:", error);
            chat = null; 
            if (error instanceof Error && (error.message.toLowerCase().includes("api key") || error.message.toLowerCase().includes("permission denied"))) {
                 throw new Error("FALHA_CONFIGURACAO_CHATBOT");
            }
            throw new Error("ERRO_INICIALIZAR_CHAT"); 
        } finally {
            chatInitializationPromise = null;
        }
    })();
    return chatInitializationPromise;
};

export const sendMessageToChatbot = async (message: string): Promise<string> => {
    if (!chat) {
        if (!isChatInitializationAttempted) {
             console.log("Chat não inicializado, tentando inicializar agora.");
            try {
                await initializeChat();
            } catch (initError) {
                console.error("Falha na tentativa de inicializar o chat ao enviar mensagem:", initError);
                 if (initError instanceof Error && initError.message === "FALHA_CONFIGURACAO_CHATBOT") {
                    return "Desculpe, o chatbot não está disponível devido a um problema de configuração. Por favor, entre em contato com o suporte do site.";
                }
                return "Desculpe, o chatbot não está disponível no momento. Tente novamente mais tarde.";
            }
        } else {
             return "Desculpe, o chatbot não está pronto. Por favor, aguarde um momento e tente novamente, ou contate o suporte se o problema persistir.";
        }
    }
    
    if (!chat) {
         return "Desculpe, o chatbot ainda não está pronto. Por favor, tente novamente em instantes.";
    }

    try {
        const response: GenerateContentResponse = await chat.sendMessage({ message });
        return response.text;
    } catch (error) {
        console.error("Erro ao enviar mensagem para o chatbot:", error);
        if (error instanceof Error && (error.message.toLowerCase().includes("api key") || error.message.toLowerCase().includes("permission denied") || error.message.toLowerCase().includes("quota"))) {
            return "Desculpe, ocorreu um problema ao comunicar com o chatbot (configuração ou limite excedido). Por favor, tente mais tarde ou contate o suporte.";
        }
        return "Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente ou contate-nos diretamente.";
    }
};